﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmInformações
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nome do Computador :")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nome do Domínio :")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nome de Usuário :")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Monitors :")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Resolução :")
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sistema Operacional :")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plataforma do Sistema :")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Versão do Sistema :")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("RAM :")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Bateria :")
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações CPU :")
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações GPU :")
        Dim TreeNode13 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("UpTime :")
        Dim TreeNode14 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Identificador :")
        Dim TreeNode15 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Data/Hora :")
        Dim TreeNode16 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cam :")
        Dim TreeNode17 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Janelas :")
        Dim TreeNode18 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Pasta do Sistema :")
        Dim TreeNode19 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Idioma :")
        Dim TreeNode20 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("País :")
        Dim TreeNode21 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Tipo de Sistema :")
        Dim TreeNode22 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Medelo do Sistema :")
        Dim TreeNode23 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Versao/Data da BIOS :")
        Dim TreeNode24 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações do Computador", New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2, TreeNode3, TreeNode4, TreeNode5, TreeNode6, TreeNode7, TreeNode8, TreeNode9, TreeNode10, TreeNode11, TreeNode12, TreeNode13, TreeNode14, TreeNode15, TreeNode16, TreeNode17, TreeNode18, TreeNode19, TreeNode20, TreeNode21, TreeNode22, TreeNode23})
        Dim TreeNode25 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Localização :")
        Dim TreeNode26 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Atributos :")
        Dim TreeNode27 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Diretório :")
        Dim TreeNode28 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Port :")
        Dim TreeNode29 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Host :")
        Dim TreeNode30 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Servidor :")
        Dim TreeNode31 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Data de Instalação :")
        Dim TreeNode32 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações do Servidor", New System.Windows.Forms.TreeNode() {TreeNode25, TreeNode26, TreeNode27, TreeNode28, TreeNode29, TreeNode30, TreeNode31})
        Dim TreeNode33 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IPV4 :")
        Dim TreeNode34 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IP Local :")
        Dim TreeNode35 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Endereço MAC :")
        Dim TreeNode36 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações da Rede", New System.Windows.Forms.TreeNode() {TreeNode33, TreeNode34, TreeNode35})
        Dim TreeNode37 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Proprietário Registrado :")
        Dim TreeNode38 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Organização Registrada :")
        Dim TreeNode39 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chave do Produto :")
        Dim TreeNode40 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("AntiVirus Instalado :")
        Dim TreeNode41 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Firewall :")
        Dim TreeNode42 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Outras informações", New System.Windows.Forms.TreeNode() {TreeNode37, TreeNode38, TreeNode39, TreeNode40, TreeNode41})
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmInformações))
        Me.TRInformações = New System.Windows.Forms.TreeView()
        Me.IM = New System.Windows.Forms.ImageList(Me.components)
        Me.PBProgress = New System.Windows.Forms.ProgressBar()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TRInformações
        '
        Me.TRInformações.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TRInformações.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TRInformações.ForeColor = System.Drawing.Color.White
        Me.TRInformações.ImageKey = "application-blue.png"
        Me.TRInformações.ImageList = Me.IM
        Me.TRInformações.Location = New System.Drawing.Point(12, 12)
        Me.TRInformações.Name = "TRInformações"
        TreeNode1.ImageKey = "132.png"
        TreeNode1.Name = "Knoten8"
        TreeNode1.Text = "Nome do Computador :"
        TreeNode2.ImageKey = "133.png"
        TreeNode2.Name = "Knoten10"
        TreeNode2.Text = "Nome do Domínio :"
        TreeNode3.ImageKey = "134.png"
        TreeNode3.Name = "Knoten11"
        TreeNode3.Text = "Nome de Usuário :"
        TreeNode4.ImageKey = "135.png"
        TreeNode4.Name = "Knoten12"
        TreeNode4.Text = "Monitors :"
        TreeNode5.ImageKey = "136.png"
        TreeNode5.Name = "Knoten13"
        TreeNode5.Text = "Resolução :"
        TreeNode6.ImageKey = "137.png"
        TreeNode6.Name = "Knoten15"
        TreeNode6.Text = "Sistema Operacional :"
        TreeNode7.ImageKey = "138.png"
        TreeNode7.Name = "Knoten16"
        TreeNode7.Text = "Plataforma do Sistema :"
        TreeNode8.ImageKey = "139.png"
        TreeNode8.Name = "Knoten17"
        TreeNode8.Text = "Versão do Sistema :"
        TreeNode9.ImageKey = "140.png"
        TreeNode9.Name = "Knoten18"
        TreeNode9.Text = "RAM :"
        TreeNode10.ImageKey = "141.png"
        TreeNode10.Name = "Knoten19"
        TreeNode10.Text = "Bateria :"
        TreeNode11.ImageKey = "142.png"
        TreeNode11.Name = "Knoten21"
        TreeNode11.Text = "Informações CPU :"
        TreeNode12.ImageKey = "144.png"
        TreeNode12.Name = "Knoten22"
        TreeNode12.Text = "Informações GPU :"
        TreeNode13.ImageKey = "146.png"
        TreeNode13.Name = "Knoten23"
        TreeNode13.Text = "UpTime :"
        TreeNode14.ImageKey = "147.png"
        TreeNode14.Name = "Node0"
        TreeNode14.Text = "Identificador :"
        TreeNode15.ImageKey = "148.png"
        TreeNode15.Name = "Node7"
        TreeNode15.Text = "Data/Hora :"
        TreeNode16.ImageKey = "149.png"
        TreeNode16.Name = "Node8"
        TreeNode16.Text = "Cam :"
        TreeNode17.ImageKey = "150.png"
        TreeNode17.Name = "Node10"
        TreeNode17.Text = "Janelas :"
        TreeNode18.ImageKey = "151.png"
        TreeNode18.Name = "Node11"
        TreeNode18.Text = "Pasta do Sistema :"
        TreeNode19.ImageKey = "152.png"
        TreeNode19.Name = "Node12"
        TreeNode19.Text = "Idioma :"
        TreeNode20.ImageKey = "153.png"
        TreeNode20.Name = "Node16"
        TreeNode20.Text = "País :"
        TreeNode21.ImageKey = "154.png"
        TreeNode21.Name = "Node13"
        TreeNode21.Text = "Tipo de Sistema :"
        TreeNode22.ImageKey = "155.png"
        TreeNode22.Name = "Node14"
        TreeNode22.Text = "Medelo do Sistema :"
        TreeNode23.ImageKey = "156.png"
        TreeNode23.Name = "Node15"
        TreeNode23.Text = "Versao/Data da BIOS :"
        TreeNode24.ImageKey = "157.png"
        TreeNode24.Name = "Node12"
        TreeNode24.Text = "Informações do Computador"
        TreeNode25.ImageKey = "120.png"
        TreeNode25.Name = "Knoten1"
        TreeNode25.SelectedImageIndex = 1
        TreeNode25.Text = "Localização :"
        TreeNode26.ImageKey = "121.png"
        TreeNode26.Name = "Knoten2"
        TreeNode26.SelectedImageIndex = 2
        TreeNode26.Text = "Atributos :"
        TreeNode27.ImageKey = "122.png"
        TreeNode27.Name = "Node1"
        TreeNode27.Text = "Diretório :"
        TreeNode28.ImageKey = "123.png"
        TreeNode28.Name = "Node2"
        TreeNode28.Text = "Port :"
        TreeNode29.ImageKey = "124.png"
        TreeNode29.Name = "Node3"
        TreeNode29.Text = "Host :"
        TreeNode30.ImageKey = "125.png"
        TreeNode30.Name = "Node4"
        TreeNode30.Text = "Servidor :"
        TreeNode31.ImageKey = "126.png"
        TreeNode31.Name = "Node5"
        TreeNode31.Text = "Data de Instalação :"
        TreeNode32.ImageKey = "118.png"
        TreeNode32.Name = "nodpr"
        TreeNode32.Text = "Informações do Servidor"
        TreeNode33.ImageKey = "128.png"
        TreeNode33.Name = "Knoten4"
        TreeNode33.Text = "IPV4 :"
        TreeNode34.ImageKey = "129.png"
        TreeNode34.Name = "Knoten5"
        TreeNode34.Text = "IP Local :"
        TreeNode35.ImageKey = "130.png"
        TreeNode35.Name = "Knoten6"
        TreeNode35.Text = "Endereço MAC :"
        TreeNode36.ImageKey = "127.png"
        TreeNode36.Name = "Node8"
        TreeNode36.Text = "Informações da Rede"
        TreeNode37.ImageKey = "158.png"
        TreeNode37.Name = "Knoten25"
        TreeNode37.Text = "Proprietário Registrado :"
        TreeNode38.ImageKey = "159.png"
        TreeNode38.Name = "Node2"
        TreeNode38.Text = "Organização Registrada :"
        TreeNode39.ImageKey = "160.png"
        TreeNode39.Name = "Knoten27"
        TreeNode39.Text = "Chave do Produto :"
        TreeNode40.ImageKey = "161.png"
        TreeNode40.Name = "Knoten28"
        TreeNode40.Text = "AntiVirus Instalado :"
        TreeNode41.ImageKey = "162.png"
        TreeNode41.Name = "Knoten0"
        TreeNode41.Text = "Firewall :"
        TreeNode42.ImageKey = "157.png"
        TreeNode42.Name = "Node26"
        TreeNode42.Text = "Outras informações"
        Me.TRInformações.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode24, TreeNode32, TreeNode36, TreeNode42})
        Me.TRInformações.SelectedImageIndex = 0
        Me.TRInformações.Size = New System.Drawing.Size(508, 293)
        Me.TRInformações.TabIndex = 3
        '
        'IM
        '
        Me.IM.ImageStream = CType(resources.GetObject("IM.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IM.TransparentColor = System.Drawing.Color.Transparent
        Me.IM.Images.SetKeyName(0, "118.png")
        Me.IM.Images.SetKeyName(1, "120.png")
        Me.IM.Images.SetKeyName(2, "121.png")
        Me.IM.Images.SetKeyName(3, "122.png")
        Me.IM.Images.SetKeyName(4, "123.png")
        Me.IM.Images.SetKeyName(5, "124.png")
        Me.IM.Images.SetKeyName(6, "125.png")
        Me.IM.Images.SetKeyName(7, "126.png")
        Me.IM.Images.SetKeyName(8, "127.png")
        Me.IM.Images.SetKeyName(9, "128.png")
        Me.IM.Images.SetKeyName(10, "129.png")
        Me.IM.Images.SetKeyName(11, "130.png")
        Me.IM.Images.SetKeyName(12, "131.png")
        Me.IM.Images.SetKeyName(13, "132.png")
        Me.IM.Images.SetKeyName(14, "133.png")
        Me.IM.Images.SetKeyName(15, "134.png")
        Me.IM.Images.SetKeyName(16, "135.png")
        Me.IM.Images.SetKeyName(17, "136.png")
        Me.IM.Images.SetKeyName(18, "137.png")
        Me.IM.Images.SetKeyName(19, "138.png")
        Me.IM.Images.SetKeyName(20, "139.png")
        Me.IM.Images.SetKeyName(21, "140.png")
        Me.IM.Images.SetKeyName(22, "141.png")
        Me.IM.Images.SetKeyName(23, "142.png")
        Me.IM.Images.SetKeyName(24, "144.png")
        Me.IM.Images.SetKeyName(25, "146.png")
        Me.IM.Images.SetKeyName(26, "147.png")
        Me.IM.Images.SetKeyName(27, "148.png")
        Me.IM.Images.SetKeyName(28, "149.png")
        Me.IM.Images.SetKeyName(29, "150.png")
        Me.IM.Images.SetKeyName(30, "151.png")
        Me.IM.Images.SetKeyName(31, "152.png")
        Me.IM.Images.SetKeyName(32, "153.png")
        Me.IM.Images.SetKeyName(33, "154.png")
        Me.IM.Images.SetKeyName(34, "155.png")
        Me.IM.Images.SetKeyName(35, "156.png")
        Me.IM.Images.SetKeyName(36, "157.png")
        Me.IM.Images.SetKeyName(37, "158.png")
        Me.IM.Images.SetKeyName(38, "159.png")
        Me.IM.Images.SetKeyName(39, "160.png")
        Me.IM.Images.SetKeyName(40, "161.png")
        Me.IM.Images.SetKeyName(41, "162.png")
        '
        'PBProgress
        '
        Me.PBProgress.Location = New System.Drawing.Point(95, 323)
        Me.PBProgress.Maximum = 38
        Me.PBProgress.Name = "PBProgress"
        Me.PBProgress.Size = New System.Drawing.Size(427, 13)
        Me.PBProgress.TabIndex = 2
        '
        'btnOK
        '
        Me.btnOK.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOK.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(12, 311)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(77, 36)
        Me.btnOK.TabIndex = 1
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'FrmInformações
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(531, 352)
        Me.ControlBox = False
        Me.Controls.Add(Me.PBProgress)
        Me.Controls.Add(Me.TRInformações)
        Me.Controls.Add(Me.btnOK)
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FrmInformações"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "INFORMAÇÕES   [PH-RAT]"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents IM As System.Windows.Forms.ImageList
    Friend WithEvents PBProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents TRInformações As System.Windows.Forms.TreeView
End Class
