﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPesonalizaçao
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPesonalizaçao))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PBBackGroundFundo = New System.Windows.Forms.PictureBox()
        Me.btTirarImagem = New System.Windows.Forms.Button()
        Me.btnAddImagem = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PBFundoContext = New System.Windows.Forms.PictureBox()
        Me.btnTirarContext = New System.Windows.Forms.Button()
        Me.btnProcurarContext = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.CKGridLines = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.PLCor = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.LVGrupos = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CM = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ExcluirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetarMeusGruposToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IM = New System.Windows.Forms.ImageList(Me.components)
        Me.btnAdicionar = New System.Windows.Forms.Button()
        Me.txtNomeGrupo = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TBPesonalizacao = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TXT_RedigitarSenha = New System.Windows.Forms.TextBox()
        Me.TXT_Senha = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TBNotificacao = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.CKMostrarIco = New System.Windows.Forms.CheckBox()
        Me.PLTitleColor = New System.Windows.Forms.Panel()
        Me.PLHeaderColor = New System.Windows.Forms.Panel()
        Me.PLContentHoverColor = New System.Windows.Forms.Panel()
        Me.PLButtonBorderColor = New System.Windows.Forms.Panel()
        Me.PLContentColor = New System.Windows.Forms.Panel()
        Me.PLBorderColor = New System.Windows.Forms.Panel()
        Me.PLButtonHoverColor = New System.Windows.Forms.Panel()
        Me.PLBodyColor = New System.Windows.Forms.Panel()
        Me.btnTitleColor = New System.Windows.Forms.Button()
        Me.btnHeaderColor = New System.Windows.Forms.Button()
        Me.btnContentHoverColor = New System.Windows.Forms.Button()
        Me.btnContentColor = New System.Windows.Forms.Button()
        Me.btnButtonHoverColor = New System.Windows.Forms.Button()
        Me.btnButtonBorderColor = New System.Windows.Forms.Button()
        Me.btnBorderColor = New System.Windows.Forms.Button()
        Me.btnBodyColor = New System.Windows.Forms.Button()
        Me.NDIconePadding = New System.Windows.Forms.NumericUpDown()
        Me.NDDescricaoPadding = New System.Windows.Forms.NumericUpDown()
        Me.NDTituloPadding = New System.Windows.Forms.NumericUpDown()
        Me.NDDuracaoAnimacao = New System.Windows.Forms.NumericUpDown()
        Me.NDIntervaloAnimacao = New System.Windows.Forms.NumericUpDown()
        Me.NDDuracao = New System.Windows.Forms.NumericUpDown()
        Me.btnMostrarNotificacao = New System.Windows.Forms.Button()
        Me.CKEfeito = New System.Windows.Forms.CheckBox()
        Me.CKMostrarGrip = New System.Windows.Forms.CheckBox()
        Me.CKMostrarMenu = New System.Windows.Forms.CheckBox()
        Me.CKMostrarBotaoFechar = New System.Windows.Forms.CheckBox()
        Me.CKMostrarNotificação = New System.Windows.Forms.CheckBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TBGrupos = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.MinhaNotificacao = New NotificationWindow.PopupNotifier()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PBBackGroundFundo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PBFundoContext, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.CM.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TBPesonalizacao.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TBNotificacao.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.NDIconePadding, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NDDescricaoPadding, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NDTituloPadding, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NDDuracaoAnimacao, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NDIntervaloAnimacao, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NDDuracao, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TBGrupos.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PBBackGroundFundo)
        Me.GroupBox1.Controls.Add(Me.btTirarImagem)
        Me.GroupBox1.Controls.Add(Me.btnAddImagem)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(4, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(251, 127)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Imagem (Background)"
        '
        'PBBackGroundFundo
        '
        Me.PBBackGroundFundo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PBBackGroundFundo.Location = New System.Drawing.Point(83, 17)
        Me.PBBackGroundFundo.Name = "PBBackGroundFundo"
        Me.PBBackGroundFundo.Size = New System.Drawing.Size(163, 104)
        Me.PBBackGroundFundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PBBackGroundFundo.TabIndex = 2
        Me.PBBackGroundFundo.TabStop = False
        '
        'btTirarImagem
        '
        Me.btTirarImagem.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btTirarImagem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btTirarImagem.Location = New System.Drawing.Point(5, 46)
        Me.btTirarImagem.Name = "btTirarImagem"
        Me.btTirarImagem.Size = New System.Drawing.Size(75, 23)
        Me.btTirarImagem.TabIndex = 1
        Me.btTirarImagem.Text = "X"
        Me.btTirarImagem.UseVisualStyleBackColor = True
        '
        'btnAddImagem
        '
        Me.btnAddImagem.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAddImagem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAddImagem.Location = New System.Drawing.Point(5, 17)
        Me.btnAddImagem.Name = "btnAddImagem"
        Me.btnAddImagem.Size = New System.Drawing.Size(75, 23)
        Me.btnAddImagem.TabIndex = 0
        Me.btnAddImagem.Text = "Procurar"
        Me.btnAddImagem.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label1.Location = New System.Drawing.Point(2, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 52)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Largura" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "701" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Altura" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "427"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PBFundoContext)
        Me.GroupBox2.Controls.Add(Me.btnTirarContext)
        Me.GroupBox2.Controls.Add(Me.btnProcurarContext)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(260, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(251, 127)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Imagem (Background Contexto)"
        '
        'PBFundoContext
        '
        Me.PBFundoContext.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PBFundoContext.Location = New System.Drawing.Point(83, 17)
        Me.PBFundoContext.Name = "PBFundoContext"
        Me.PBFundoContext.Size = New System.Drawing.Size(163, 104)
        Me.PBFundoContext.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PBFundoContext.TabIndex = 2
        Me.PBFundoContext.TabStop = False
        '
        'btnTirarContext
        '
        Me.btnTirarContext.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTirarContext.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTirarContext.Location = New System.Drawing.Point(5, 46)
        Me.btnTirarContext.Name = "btnTirarContext"
        Me.btnTirarContext.Size = New System.Drawing.Size(75, 23)
        Me.btnTirarContext.TabIndex = 1
        Me.btnTirarContext.Text = "X"
        Me.btnTirarContext.UseVisualStyleBackColor = True
        '
        'btnProcurarContext
        '
        Me.btnProcurarContext.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnProcurarContext.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProcurarContext.Location = New System.Drawing.Point(5, 17)
        Me.btnProcurarContext.Name = "btnProcurarContext"
        Me.btnProcurarContext.Size = New System.Drawing.Size(75, 23)
        Me.btnProcurarContext.TabIndex = 0
        Me.btnProcurarContext.Text = "Procurar"
        Me.btnProcurarContext.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Label3.Location = New System.Drawing.Point(2, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 52)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Largura" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "220" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Altura" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "378"
        '
        'btnOK
        '
        Me.btnOK.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOK.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.btnOK.Location = New System.Drawing.Point(4, 448)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(522, 29)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "Salvar"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.CKGridLines)
        Me.GroupBox3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox3.ForeColor = System.Drawing.Color.White
        Me.GroupBox3.Location = New System.Drawing.Point(260, 130)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(251, 47)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Linhas de Grade"
        '
        'CKGridLines
        '
        Me.CKGridLines.AutoSize = True
        Me.CKGridLines.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKGridLines.Location = New System.Drawing.Point(8, 20)
        Me.CKGridLines.Name = "CKGridLines"
        Me.CKGridLines.Size = New System.Drawing.Size(119, 17)
        Me.CKGridLines.TabIndex = 0
        Me.CKGridLines.Text = "Mostrar GridLines"
        Me.CKGridLines.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.PLCor)
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox4.ForeColor = System.Drawing.Color.White
        Me.GroupBox4.Location = New System.Drawing.Point(4, 130)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(251, 47)
        Me.GroupBox4.TabIndex = 6
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Cores"
        '
        'PLCor
        '
        Me.PLCor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLCor.Location = New System.Drawing.Point(186, 12)
        Me.PLCor.Name = "PLCor"
        Me.PLCor.Size = New System.Drawing.Size(59, 29)
        Me.PLCor.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button1.Location = New System.Drawing.Point(6, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(174, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Novo"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.LVGrupos)
        Me.GroupBox6.Controls.Add(Me.btnAdicionar)
        Me.GroupBox6.Controls.Add(Me.txtNomeGrupo)
        Me.GroupBox6.Controls.Add(Me.Label5)
        Me.GroupBox6.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox6.ForeColor = System.Drawing.Color.White
        Me.GroupBox6.Location = New System.Drawing.Point(4, 2)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(507, 406)
        Me.GroupBox6.TabIndex = 6
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Grupos (Vitimas)"
        '
        'LVGrupos
        '
        Me.LVGrupos.BackColor = System.Drawing.Color.Black
        Me.LVGrupos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LVGrupos.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.LVGrupos.ContextMenuStrip = Me.CM
        Me.LVGrupos.ForeColor = System.Drawing.Color.White
        Me.LVGrupos.FullRowSelect = True
        Me.LVGrupos.GridLines = True
        Me.LVGrupos.HideSelection = False
        Me.LVGrupos.Location = New System.Drawing.Point(75, 19)
        Me.LVGrupos.Name = "LVGrupos"
        Me.LVGrupos.Size = New System.Drawing.Size(356, 322)
        Me.LVGrupos.SmallImageList = Me.IM
        Me.LVGrupos.TabIndex = 5
        Me.LVGrupos.UseCompatibleStateImageBehavior = False
        Me.LVGrupos.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "ID"
        Me.ColumnHeader1.Width = 64
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Nome"
        Me.ColumnHeader2.Width = 167
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Data de Criação"
        Me.ColumnHeader3.Width = 125
        '
        'CM
        '
        Me.CM.BackColor = System.Drawing.Color.Black
        Me.CM.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExcluirToolStripMenuItem, Me.ResetarMeusGruposToolStripMenuItem})
        Me.CM.Name = "CM"
        Me.CM.ShowImageMargin = False
        Me.CM.Size = New System.Drawing.Size(161, 48)
        '
        'ExcluirToolStripMenuItem
        '
        Me.ExcluirToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ExcluirToolStripMenuItem.Name = "ExcluirToolStripMenuItem"
        Me.ExcluirToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.ExcluirToolStripMenuItem.Text = "Excluir"
        '
        'ResetarMeusGruposToolStripMenuItem
        '
        Me.ResetarMeusGruposToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ResetarMeusGruposToolStripMenuItem.Name = "ResetarMeusGruposToolStripMenuItem"
        Me.ResetarMeusGruposToolStripMenuItem.Size = New System.Drawing.Size(160, 22)
        Me.ResetarMeusGruposToolStripMenuItem.Text = "Resetar Meus Grupos"
        '
        'IM
        '
        Me.IM.ImageStream = CType(resources.GetObject("IM.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IM.TransparentColor = System.Drawing.Color.Transparent
        Me.IM.Images.SetKeyName(0, "240.png")
        Me.IM.Images.SetKeyName(1, "241.png")
        Me.IM.Images.SetKeyName(2, "242.png")
        Me.IM.Images.SetKeyName(3, "253.png")
        '
        'btnAdicionar
        '
        Me.btnAdicionar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAdicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAdicionar.Location = New System.Drawing.Point(356, 358)
        Me.btnAdicionar.Name = "btnAdicionar"
        Me.btnAdicionar.Size = New System.Drawing.Size(75, 23)
        Me.btnAdicionar.TabIndex = 2
        Me.btnAdicionar.Text = "Adicionar"
        Me.btnAdicionar.UseVisualStyleBackColor = True
        '
        'txtNomeGrupo
        '
        Me.txtNomeGrupo.BackColor = System.Drawing.Color.Black
        Me.txtNomeGrupo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNomeGrupo.ForeColor = System.Drawing.Color.White
        Me.txtNomeGrupo.Location = New System.Drawing.Point(75, 359)
        Me.txtNomeGrupo.Name = "txtNomeGrupo"
        Me.txtNomeGrupo.Size = New System.Drawing.Size(277, 22)
        Me.txtNomeGrupo.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(72, 344)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Nome"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TBPesonalizacao)
        Me.TabControl1.Controls.Add(Me.TBNotificacao)
        Me.TabControl1.Controls.Add(Me.TBGrupos)
        Me.TabControl1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TabControl1.ImageList = Me.IM
        Me.TabControl1.Location = New System.Drawing.Point(4, 3)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(522, 441)
        Me.TabControl1.TabIndex = 7
        '
        'TBPesonalizacao
        '
        Me.TBPesonalizacao.BackColor = System.Drawing.Color.Black
        Me.TBPesonalizacao.Controls.Add(Me.GroupBox7)
        Me.TBPesonalizacao.Controls.Add(Me.GroupBox1)
        Me.TBPesonalizacao.Controls.Add(Me.GroupBox2)
        Me.TBPesonalizacao.Controls.Add(Me.GroupBox4)
        Me.TBPesonalizacao.Controls.Add(Me.GroupBox3)
        Me.TBPesonalizacao.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TBPesonalizacao.ImageIndex = 0
        Me.TBPesonalizacao.Location = New System.Drawing.Point(4, 25)
        Me.TBPesonalizacao.Name = "TBPesonalizacao"
        Me.TBPesonalizacao.Padding = New System.Windows.Forms.Padding(3)
        Me.TBPesonalizacao.Size = New System.Drawing.Size(514, 412)
        Me.TBPesonalizacao.TabIndex = 0
        Me.TBPesonalizacao.Text = "Pesonalização"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Button3)
        Me.GroupBox7.Controls.Add(Me.Button2)
        Me.GroupBox7.Controls.Add(Me.TXT_RedigitarSenha)
        Me.GroupBox7.Controls.Add(Me.TXT_Senha)
        Me.GroupBox7.Controls.Add(Me.Label19)
        Me.GroupBox7.Controls.Add(Me.Label6)
        Me.GroupBox7.ForeColor = System.Drawing.Color.White
        Me.GroupBox7.Location = New System.Drawing.Point(4, 179)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(507, 101)
        Me.GroupBox7.TabIndex = 7
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Segurança"
        '
        'Button3
        '
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Location = New System.Drawing.Point(426, 72)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Excluir"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(426, 32)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 38)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "OK"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TXT_RedigitarSenha
        '
        Me.TXT_RedigitarSenha.BackColor = System.Drawing.Color.Black
        Me.TXT_RedigitarSenha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXT_RedigitarSenha.ForeColor = System.Drawing.Color.White
        Me.TXT_RedigitarSenha.Location = New System.Drawing.Point(7, 72)
        Me.TXT_RedigitarSenha.Name = "TXT_RedigitarSenha"
        Me.TXT_RedigitarSenha.Size = New System.Drawing.Size(413, 22)
        Me.TXT_RedigitarSenha.TabIndex = 3
        Me.TXT_RedigitarSenha.UseSystemPasswordChar = True
        '
        'TXT_Senha
        '
        Me.TXT_Senha.BackColor = System.Drawing.Color.Black
        Me.TXT_Senha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXT_Senha.ForeColor = System.Drawing.Color.White
        Me.TXT_Senha.Location = New System.Drawing.Point(7, 32)
        Me.TXT_Senha.Name = "TXT_Senha"
        Me.TXT_Senha.Size = New System.Drawing.Size(413, 22)
        Me.TXT_Senha.TabIndex = 2
        Me.TXT_Senha.UseSystemPasswordChar = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(4, 57)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(98, 13)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Redigitar a Senha"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 17)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Senha"
        '
        'TBNotificacao
        '
        Me.TBNotificacao.BackColor = System.Drawing.Color.Black
        Me.TBNotificacao.Controls.Add(Me.GroupBox5)
        Me.TBNotificacao.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TBNotificacao.ImageIndex = 1
        Me.TBNotificacao.Location = New System.Drawing.Point(4, 25)
        Me.TBNotificacao.Name = "TBNotificacao"
        Me.TBNotificacao.Padding = New System.Windows.Forms.Padding(3)
        Me.TBNotificacao.Size = New System.Drawing.Size(514, 412)
        Me.TBNotificacao.TabIndex = 1
        Me.TBNotificacao.Text = "Notificação"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.CKMostrarIco)
        Me.GroupBox5.Controls.Add(Me.PLTitleColor)
        Me.GroupBox5.Controls.Add(Me.PLHeaderColor)
        Me.GroupBox5.Controls.Add(Me.PLContentHoverColor)
        Me.GroupBox5.Controls.Add(Me.PLButtonBorderColor)
        Me.GroupBox5.Controls.Add(Me.PLContentColor)
        Me.GroupBox5.Controls.Add(Me.PLBorderColor)
        Me.GroupBox5.Controls.Add(Me.PLButtonHoverColor)
        Me.GroupBox5.Controls.Add(Me.PLBodyColor)
        Me.GroupBox5.Controls.Add(Me.btnTitleColor)
        Me.GroupBox5.Controls.Add(Me.btnHeaderColor)
        Me.GroupBox5.Controls.Add(Me.btnContentHoverColor)
        Me.GroupBox5.Controls.Add(Me.btnContentColor)
        Me.GroupBox5.Controls.Add(Me.btnButtonHoverColor)
        Me.GroupBox5.Controls.Add(Me.btnButtonBorderColor)
        Me.GroupBox5.Controls.Add(Me.btnBorderColor)
        Me.GroupBox5.Controls.Add(Me.btnBodyColor)
        Me.GroupBox5.Controls.Add(Me.NDIconePadding)
        Me.GroupBox5.Controls.Add(Me.NDDescricaoPadding)
        Me.GroupBox5.Controls.Add(Me.NDTituloPadding)
        Me.GroupBox5.Controls.Add(Me.NDDuracaoAnimacao)
        Me.GroupBox5.Controls.Add(Me.NDIntervaloAnimacao)
        Me.GroupBox5.Controls.Add(Me.NDDuracao)
        Me.GroupBox5.Controls.Add(Me.btnMostrarNotificacao)
        Me.GroupBox5.Controls.Add(Me.CKEfeito)
        Me.GroupBox5.Controls.Add(Me.CKMostrarGrip)
        Me.GroupBox5.Controls.Add(Me.CKMostrarMenu)
        Me.GroupBox5.Controls.Add(Me.CKMostrarBotaoFechar)
        Me.GroupBox5.Controls.Add(Me.CKMostrarNotificação)
        Me.GroupBox5.Controls.Add(Me.label8)
        Me.GroupBox5.Controls.Add(Me.Label9)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.Label4)
        Me.GroupBox5.Controls.Add(Me.label7)
        Me.GroupBox5.Controls.Add(Me.Label2)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Controls.Add(Me.Label18)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Controls.Add(Me.Label16)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox5.ForeColor = System.Drawing.Color.White
        Me.GroupBox5.Location = New System.Drawing.Point(4, 2)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(507, 406)
        Me.GroupBox5.TabIndex = 7
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Notificação Visual"
        '
        'CKMostrarIco
        '
        Me.CKMostrarIco.AutoSize = True
        Me.CKMostrarIco.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKMostrarIco.Location = New System.Drawing.Point(9, 44)
        Me.CKMostrarIco.Name = "CKMostrarIco"
        Me.CKMostrarIco.Size = New System.Drawing.Size(98, 17)
        Me.CKMostrarIco.TabIndex = 70
        Me.CKMostrarIco.Text = "Mostrar ícone"
        Me.CKMostrarIco.UseVisualStyleBackColor = True
        '
        'PLTitleColor
        '
        Me.PLTitleColor.BackColor = System.Drawing.Color.Gray
        Me.PLTitleColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLTitleColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLTitleColor.Location = New System.Drawing.Point(211, 376)
        Me.PLTitleColor.Name = "PLTitleColor"
        Me.PLTitleColor.Size = New System.Drawing.Size(30, 23)
        Me.PLTitleColor.TabIndex = 69
        '
        'PLHeaderColor
        '
        Me.PLHeaderColor.BackColor = System.Drawing.SystemColors.ControlDark
        Me.PLHeaderColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLHeaderColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLHeaderColor.Location = New System.Drawing.Point(211, 350)
        Me.PLHeaderColor.Name = "PLHeaderColor"
        Me.PLHeaderColor.Size = New System.Drawing.Size(30, 23)
        Me.PLHeaderColor.TabIndex = 68
        '
        'PLContentHoverColor
        '
        Me.PLContentHoverColor.BackColor = System.Drawing.SystemColors.HotTrack
        Me.PLContentHoverColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLContentHoverColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLContentHoverColor.Location = New System.Drawing.Point(211, 324)
        Me.PLContentHoverColor.Name = "PLContentHoverColor"
        Me.PLContentHoverColor.Size = New System.Drawing.Size(30, 23)
        Me.PLContentHoverColor.TabIndex = 67
        '
        'PLButtonBorderColor
        '
        Me.PLButtonBorderColor.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.PLButtonBorderColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLButtonBorderColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLButtonBorderColor.Location = New System.Drawing.Point(211, 246)
        Me.PLButtonBorderColor.Name = "PLButtonBorderColor"
        Me.PLButtonBorderColor.Size = New System.Drawing.Size(30, 23)
        Me.PLButtonBorderColor.TabIndex = 64
        '
        'PLContentColor
        '
        Me.PLContentColor.BackColor = System.Drawing.SystemColors.ControlText
        Me.PLContentColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLContentColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLContentColor.Location = New System.Drawing.Point(211, 298)
        Me.PLContentColor.Name = "PLContentColor"
        Me.PLContentColor.Size = New System.Drawing.Size(30, 23)
        Me.PLContentColor.TabIndex = 66
        '
        'PLBorderColor
        '
        Me.PLBorderColor.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.PLBorderColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLBorderColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLBorderColor.Location = New System.Drawing.Point(211, 220)
        Me.PLBorderColor.Name = "PLBorderColor"
        Me.PLBorderColor.Size = New System.Drawing.Size(30, 23)
        Me.PLBorderColor.TabIndex = 64
        '
        'PLButtonHoverColor
        '
        Me.PLButtonHoverColor.BackColor = System.Drawing.SystemColors.Highlight
        Me.PLButtonHoverColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLButtonHoverColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLButtonHoverColor.Location = New System.Drawing.Point(211, 272)
        Me.PLButtonHoverColor.Name = "PLButtonHoverColor"
        Me.PLButtonHoverColor.Size = New System.Drawing.Size(30, 23)
        Me.PLButtonHoverColor.TabIndex = 65
        '
        'PLBodyColor
        '
        Me.PLBodyColor.BackColor = System.Drawing.SystemColors.Control
        Me.PLBodyColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PLBodyColor.ForeColor = System.Drawing.Color.Transparent
        Me.PLBodyColor.Location = New System.Drawing.Point(211, 194)
        Me.PLBodyColor.Name = "PLBodyColor"
        Me.PLBodyColor.Size = New System.Drawing.Size(30, 23)
        Me.PLBodyColor.TabIndex = 63
        '
        'btnTitleColor
        '
        Me.btnTitleColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTitleColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTitleColor.Location = New System.Drawing.Point(171, 376)
        Me.btnTitleColor.Name = "btnTitleColor"
        Me.btnTitleColor.Size = New System.Drawing.Size(30, 23)
        Me.btnTitleColor.TabIndex = 62
        Me.btnTitleColor.Text = "C"
        Me.btnTitleColor.UseVisualStyleBackColor = True
        '
        'btnHeaderColor
        '
        Me.btnHeaderColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHeaderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHeaderColor.Location = New System.Drawing.Point(171, 350)
        Me.btnHeaderColor.Name = "btnHeaderColor"
        Me.btnHeaderColor.Size = New System.Drawing.Size(30, 23)
        Me.btnHeaderColor.TabIndex = 61
        Me.btnHeaderColor.Text = "C"
        Me.btnHeaderColor.UseVisualStyleBackColor = True
        '
        'btnContentHoverColor
        '
        Me.btnContentHoverColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnContentHoverColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnContentHoverColor.Location = New System.Drawing.Point(171, 324)
        Me.btnContentHoverColor.Name = "btnContentHoverColor"
        Me.btnContentHoverColor.Size = New System.Drawing.Size(30, 23)
        Me.btnContentHoverColor.TabIndex = 60
        Me.btnContentHoverColor.Text = "C"
        Me.btnContentHoverColor.UseVisualStyleBackColor = True
        '
        'btnContentColor
        '
        Me.btnContentColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnContentColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnContentColor.Location = New System.Drawing.Point(171, 298)
        Me.btnContentColor.Name = "btnContentColor"
        Me.btnContentColor.Size = New System.Drawing.Size(30, 23)
        Me.btnContentColor.TabIndex = 59
        Me.btnContentColor.Text = "C"
        Me.btnContentColor.UseVisualStyleBackColor = True
        '
        'btnButtonHoverColor
        '
        Me.btnButtonHoverColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnButtonHoverColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnButtonHoverColor.Location = New System.Drawing.Point(171, 272)
        Me.btnButtonHoverColor.Name = "btnButtonHoverColor"
        Me.btnButtonHoverColor.Size = New System.Drawing.Size(30, 23)
        Me.btnButtonHoverColor.TabIndex = 58
        Me.btnButtonHoverColor.Text = "C"
        Me.btnButtonHoverColor.UseVisualStyleBackColor = True
        '
        'btnButtonBorderColor
        '
        Me.btnButtonBorderColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnButtonBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnButtonBorderColor.Location = New System.Drawing.Point(171, 246)
        Me.btnButtonBorderColor.Name = "btnButtonBorderColor"
        Me.btnButtonBorderColor.Size = New System.Drawing.Size(30, 23)
        Me.btnButtonBorderColor.TabIndex = 57
        Me.btnButtonBorderColor.Text = "C"
        Me.btnButtonBorderColor.UseVisualStyleBackColor = True
        '
        'btnBorderColor
        '
        Me.btnBorderColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBorderColor.Location = New System.Drawing.Point(171, 220)
        Me.btnBorderColor.Name = "btnBorderColor"
        Me.btnBorderColor.Size = New System.Drawing.Size(30, 23)
        Me.btnBorderColor.TabIndex = 56
        Me.btnBorderColor.Text = "C"
        Me.btnBorderColor.UseVisualStyleBackColor = True
        '
        'btnBodyColor
        '
        Me.btnBodyColor.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBodyColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBodyColor.Location = New System.Drawing.Point(171, 194)
        Me.btnBodyColor.Name = "btnBodyColor"
        Me.btnBodyColor.Size = New System.Drawing.Size(30, 23)
        Me.btnBodyColor.TabIndex = 47
        Me.btnBodyColor.Text = "C"
        Me.btnBodyColor.UseVisualStyleBackColor = True
        '
        'NDIconePadding
        '
        Me.NDIconePadding.BackColor = System.Drawing.Color.Black
        Me.NDIconePadding.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NDIconePadding.ForeColor = System.Drawing.Color.White
        Me.NDIconePadding.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NDIconePadding.Location = New System.Drawing.Point(328, 164)
        Me.NDIconePadding.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NDIconePadding.Name = "NDIconePadding"
        Me.NDIconePadding.Size = New System.Drawing.Size(100, 22)
        Me.NDIconePadding.TabIndex = 46
        '
        'NDDescricaoPadding
        '
        Me.NDDescricaoPadding.BackColor = System.Drawing.Color.Black
        Me.NDDescricaoPadding.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NDDescricaoPadding.ForeColor = System.Drawing.Color.White
        Me.NDDescricaoPadding.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NDDescricaoPadding.Location = New System.Drawing.Point(328, 139)
        Me.NDDescricaoPadding.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NDDescricaoPadding.Name = "NDDescricaoPadding"
        Me.NDDescricaoPadding.Size = New System.Drawing.Size(100, 22)
        Me.NDDescricaoPadding.TabIndex = 45
        '
        'NDTituloPadding
        '
        Me.NDTituloPadding.BackColor = System.Drawing.Color.Black
        Me.NDTituloPadding.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NDTituloPadding.ForeColor = System.Drawing.Color.White
        Me.NDTituloPadding.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NDTituloPadding.Location = New System.Drawing.Point(328, 114)
        Me.NDTituloPadding.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NDTituloPadding.Name = "NDTituloPadding"
        Me.NDTituloPadding.Size = New System.Drawing.Size(100, 22)
        Me.NDTituloPadding.TabIndex = 44
        '
        'NDDuracaoAnimacao
        '
        Me.NDDuracaoAnimacao.BackColor = System.Drawing.Color.Black
        Me.NDDuracaoAnimacao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NDDuracaoAnimacao.ForeColor = System.Drawing.Color.White
        Me.NDDuracaoAnimacao.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NDDuracaoAnimacao.Location = New System.Drawing.Point(328, 89)
        Me.NDDuracaoAnimacao.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NDDuracaoAnimacao.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NDDuracaoAnimacao.Name = "NDDuracaoAnimacao"
        Me.NDDuracaoAnimacao.Size = New System.Drawing.Size(100, 22)
        Me.NDDuracaoAnimacao.TabIndex = 43
        Me.NDDuracaoAnimacao.Value = New Decimal(New Integer() {1000, 0, 0, 0})
        '
        'NDIntervaloAnimacao
        '
        Me.NDIntervaloAnimacao.BackColor = System.Drawing.Color.Black
        Me.NDIntervaloAnimacao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NDIntervaloAnimacao.ForeColor = System.Drawing.Color.White
        Me.NDIntervaloAnimacao.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.NDIntervaloAnimacao.Location = New System.Drawing.Point(328, 64)
        Me.NDIntervaloAnimacao.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NDIntervaloAnimacao.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NDIntervaloAnimacao.Name = "NDIntervaloAnimacao"
        Me.NDIntervaloAnimacao.Size = New System.Drawing.Size(100, 22)
        Me.NDIntervaloAnimacao.TabIndex = 42
        Me.NDIntervaloAnimacao.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'NDDuracao
        '
        Me.NDDuracao.BackColor = System.Drawing.Color.Black
        Me.NDDuracao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NDDuracao.ForeColor = System.Drawing.Color.White
        Me.NDDuracao.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NDDuracao.Location = New System.Drawing.Point(328, 39)
        Me.NDDuracao.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NDDuracao.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NDDuracao.Name = "NDDuracao"
        Me.NDDuracao.Size = New System.Drawing.Size(100, 22)
        Me.NDDuracao.TabIndex = 41
        Me.NDDuracao.Value = New Decimal(New Integer() {3000, 0, 0, 0})
        '
        'btnMostrarNotificacao
        '
        Me.btnMostrarNotificacao.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMostrarNotificacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMostrarNotificacao.Location = New System.Drawing.Point(354, 368)
        Me.btnMostrarNotificacao.Name = "btnMostrarNotificacao"
        Me.btnMostrarNotificacao.Size = New System.Drawing.Size(147, 31)
        Me.btnMostrarNotificacao.TabIndex = 40
        Me.btnMostrarNotificacao.Text = "Mostrar Notificação"
        Me.btnMostrarNotificacao.UseVisualStyleBackColor = True
        '
        'CKEfeito
        '
        Me.CKEfeito.AutoSize = True
        Me.CKEfeito.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKEfeito.Location = New System.Drawing.Point(9, 144)
        Me.CKEfeito.Name = "CKEfeito"
        Me.CKEfeito.Size = New System.Drawing.Size(90, 17)
        Me.CKEfeito.TabIndex = 33
        Me.CKEfeito.Text = "Scroll in/out"
        Me.CKEfeito.UseVisualStyleBackColor = True
        '
        'CKMostrarGrip
        '
        Me.CKMostrarGrip.AutoSize = True
        Me.CKMostrarGrip.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKMostrarGrip.Location = New System.Drawing.Point(9, 119)
        Me.CKMostrarGrip.Name = "CKMostrarGrip"
        Me.CKMostrarGrip.Size = New System.Drawing.Size(92, 17)
        Me.CKMostrarGrip.TabIndex = 30
        Me.CKMostrarGrip.Text = "Mostrar Grip"
        Me.CKMostrarGrip.UseVisualStyleBackColor = True
        '
        'CKMostrarMenu
        '
        Me.CKMostrarMenu.AutoSize = True
        Me.CKMostrarMenu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKMostrarMenu.Location = New System.Drawing.Point(9, 94)
        Me.CKMostrarMenu.Name = "CKMostrarMenu"
        Me.CKMostrarMenu.Size = New System.Drawing.Size(158, 17)
        Me.CKMostrarMenu.TabIndex = 25
        Me.CKMostrarMenu.Text = "Mostrar Menu de Opções"
        Me.CKMostrarMenu.UseVisualStyleBackColor = True
        '
        'CKMostrarBotaoFechar
        '
        Me.CKMostrarBotaoFechar.AutoSize = True
        Me.CKMostrarBotaoFechar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKMostrarBotaoFechar.Location = New System.Drawing.Point(9, 69)
        Me.CKMostrarBotaoFechar.Name = "CKMostrarBotaoFechar"
        Me.CKMostrarBotaoFechar.Size = New System.Drawing.Size(154, 17)
        Me.CKMostrarBotaoFechar.TabIndex = 24
        Me.CKMostrarBotaoFechar.Text = "Mostrar Botão de Fechar"
        Me.CKMostrarBotaoFechar.UseVisualStyleBackColor = True
        '
        'CKMostrarNotificação
        '
        Me.CKMostrarNotificação.AutoSize = True
        Me.CKMostrarNotificação.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKMostrarNotificação.Font = New System.Drawing.Font("Segoe UI", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CKMostrarNotificação.ForeColor = System.Drawing.Color.Yellow
        Me.CKMostrarNotificação.Location = New System.Drawing.Point(9, 20)
        Me.CKMostrarNotificação.Name = "CKMostrarNotificação"
        Me.CKMostrarNotificação.Size = New System.Drawing.Size(153, 17)
        Me.CKMostrarNotificação.TabIndex = 0
        Me.CKMostrarNotificação.Text = "Ativar Notificação Visual"
        Me.CKMostrarNotificação.UseVisualStyleBackColor = True
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Location = New System.Drawing.Point(168, 94)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(155, 13)
        Me.label8.TabIndex = 38
        Me.label8.Text = "Duração da Animação [MS] :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(168, 69)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(158, 13)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "Intervalo de Animação [MS] :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(168, 44)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(84, 13)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "Duração [MS] :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(168, 119)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 13)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Título Padding [PX] :"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(168, 144)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(134, 13)
        Me.label7.TabIndex = 37
        Me.label7.Text = "Descrição Padding [PX] :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(168, 169)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(113, 13)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "Ícone Padding [PX] :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(9, 381)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(63, 13)
        Me.Label17.TabIndex = 55
        Me.Label17.Text = "TitleColor :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(9, 355)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(78, 13)
        Me.Label18.TabIndex = 54
        Me.Label18.Text = "HeaderColor :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(9, 329)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(114, 13)
        Me.Label15.TabIndex = 53
        Me.Label15.Text = "ContentHoverColor :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(9, 303)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(83, 13)
        Me.Label16.TabIndex = 52
        Me.Label16.Text = "ContentColor :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(9, 277)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(108, 13)
        Me.Label13.TabIndex = 51
        Me.Label13.Text = "ButtonHoverColor :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(9, 251)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(112, 13)
        Me.Label14.TabIndex = 50
        Me.Label14.Text = "ButtonBorderColor :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(9, 225)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(76, 13)
        Me.Label12.TabIndex = 49
        Me.Label12.Text = "BorderColor :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(9, 199)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(68, 13)
        Me.Label11.TabIndex = 48
        Me.Label11.Text = "BodyColor :"
        '
        'TBGrupos
        '
        Me.TBGrupos.BackColor = System.Drawing.Color.Black
        Me.TBGrupos.Controls.Add(Me.GroupBox6)
        Me.TBGrupos.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold)
        Me.TBGrupos.ImageIndex = 2
        Me.TBGrupos.Location = New System.Drawing.Point(4, 25)
        Me.TBGrupos.Name = "TBGrupos"
        Me.TBGrupos.Size = New System.Drawing.Size(514, 412)
        Me.TBGrupos.TabIndex = 2
        Me.TBGrupos.Text = "Grupos"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.ForeColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(-20, -8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(26, 618)
        Me.Panel1.TabIndex = 8
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(524, -19)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(46, 475)
        Me.Panel2.TabIndex = 9
        '
        'MinhaNotificacao
        '
        Me.MinhaNotificacao.ContentFont = New System.Drawing.Font("Tahoma", 8.0!)
        Me.MinhaNotificacao.ContentText = Nothing
        Me.MinhaNotificacao.Image = Nothing
        Me.MinhaNotificacao.OptionsMenu = Nothing
        Me.MinhaNotificacao.Size = New System.Drawing.Size(400, 100)
        Me.MinhaNotificacao.TitleFont = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.MinhaNotificacao.TitleText = Nothing
        '
        'Panel11
        '
        Me.Panel11.Location = New System.Drawing.Point(-27, 442)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(641, 50)
        Me.Panel11.TabIndex = 10
        '
        'FrmPesonalizaçao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(529, 482)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.Panel11)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TabControl1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "FrmPesonalizaçao"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "[CONFIGURAÇÕES]    PH-RAT"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PBBackGroundFundo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PBFundoContext, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.CM.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TBPesonalizacao.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.TBNotificacao.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.NDIconePadding, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NDDescricaoPadding, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NDTituloPadding, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NDDuracaoAnimacao, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NDIntervaloAnimacao, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NDDuracao, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TBGrupos.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PBBackGroundFundo As System.Windows.Forms.PictureBox
    Friend WithEvents btTirarImagem As System.Windows.Forms.Button
    Friend WithEvents btnAddImagem As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents PBFundoContext As System.Windows.Forms.PictureBox
    Friend WithEvents btnTirarContext As System.Windows.Forms.Button
    Friend WithEvents btnProcurarContext As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents CKGridLines As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PLCor As System.Windows.Forms.Panel
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents btnAdicionar As System.Windows.Forms.Button
    Friend WithEvents txtNomeGrupo As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TBPesonalizacao As System.Windows.Forms.TabPage
    Friend WithEvents TBNotificacao As System.Windows.Forms.TabPage
    Friend WithEvents TBGrupos As System.Windows.Forms.TabPage
    Friend WithEvents IM As System.Windows.Forms.ImageList
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents CKMostrarNotificação As System.Windows.Forms.CheckBox
    Friend WithEvents LVGrupos As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents label8 As System.Windows.Forms.Label
    Private WithEvents CKEfeito As System.Windows.Forms.CheckBox
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents CKMostrarGrip As System.Windows.Forms.CheckBox
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents Label10 As System.Windows.Forms.Label
    Private WithEvents CKMostrarMenu As System.Windows.Forms.CheckBox
    Private WithEvents CKMostrarBotaoFechar As System.Windows.Forms.CheckBox
    Friend WithEvents btnMostrarNotificacao As System.Windows.Forms.Button
    Friend WithEvents NDDuracao As System.Windows.Forms.NumericUpDown
    Friend WithEvents NDIntervaloAnimacao As System.Windows.Forms.NumericUpDown
    Friend WithEvents NDDuracaoAnimacao As System.Windows.Forms.NumericUpDown
    Friend WithEvents NDTituloPadding As System.Windows.Forms.NumericUpDown
    Friend WithEvents NDIconePadding As System.Windows.Forms.NumericUpDown
    Friend WithEvents NDDescricaoPadding As System.Windows.Forms.NumericUpDown
    Friend WithEvents MinhaNotificacao As NotificationWindow.PopupNotifier
    Private WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnBodyColor As System.Windows.Forms.Button
    Friend WithEvents btnTitleColor As System.Windows.Forms.Button
    Friend WithEvents btnHeaderColor As System.Windows.Forms.Button
    Friend WithEvents btnContentHoverColor As System.Windows.Forms.Button
    Friend WithEvents btnContentColor As System.Windows.Forms.Button
    Friend WithEvents btnButtonHoverColor As System.Windows.Forms.Button
    Friend WithEvents btnButtonBorderColor As System.Windows.Forms.Button
    Friend WithEvents btnBorderColor As System.Windows.Forms.Button
    Private WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents Label18 As System.Windows.Forms.Label
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents Label13 As System.Windows.Forms.Label
    Private WithEvents Label14 As System.Windows.Forms.Label
    Private WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents PLTitleColor As System.Windows.Forms.Panel
    Friend WithEvents PLHeaderColor As System.Windows.Forms.Panel
    Friend WithEvents PLContentHoverColor As System.Windows.Forms.Panel
    Friend WithEvents PLButtonBorderColor As System.Windows.Forms.Panel
    Friend WithEvents PLContentColor As System.Windows.Forms.Panel
    Friend WithEvents PLBorderColor As System.Windows.Forms.Panel
    Friend WithEvents PLButtonHoverColor As System.Windows.Forms.Panel
    Friend WithEvents PLBodyColor As System.Windows.Forms.Panel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents CKMostrarIco As System.Windows.Forms.CheckBox
    Friend WithEvents CM As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ExcluirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResetarMeusGruposToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents TXT_RedigitarSenha As System.Windows.Forms.TextBox
    Friend WithEvents TXT_Senha As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
End Class
