﻿Imports System
Imports System.Collections.Generic
Public Class MdFMcach
    ' Fields
    Public files As List(Of String) = New List(Of String)
    Public folders As List(Of String) = New List(Of String)
    Public Path As String
End Class