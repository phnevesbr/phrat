﻿Public Class FrmCreditos

    Sub New()
        InitializeComponent()
        TMPisca.Start()
    End Sub

    Private Sub LinkLabel1_LinkClicked_1(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Diagnostics.Process.Start("https://www.facebook.com/phneves8/")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Diagnostics.Process.Start("https://www.youtube.com/channel/UCXGCuyy3JES0bsRGcZWG2Jw")
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        Diagnostics.Process.Start("https://www.instagram.com/phneves_br/")
    End Sub

    Private Sub TMPisca_Tick(sender As Object, e As EventArgs) Handles TMPisca.Tick
        Application.DoEvents()
        Threading.Thread.Sleep(5)

    End Sub

    Private Sub FrmCreditos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        TMPisca.Stop()
        TMPisca.Dispose()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub FrmCreditos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class