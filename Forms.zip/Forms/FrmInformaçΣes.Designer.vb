﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmInformações
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim TreeNode43 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nome do Computador :")
        Dim TreeNode44 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nome do Domínio :")
        Dim TreeNode45 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nome de Usuário :")
        Dim TreeNode46 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Monitors :")
        Dim TreeNode47 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Resolução :")
        Dim TreeNode48 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Sistema Operacional :")
        Dim TreeNode49 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Plataforma do Sistema :")
        Dim TreeNode50 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Versão do Sistema :")
        Dim TreeNode51 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("RAM :")
        Dim TreeNode52 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Bateria :")
        Dim TreeNode53 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações CPU :")
        Dim TreeNode54 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações GPU :")
        Dim TreeNode55 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("UpTime :")
        Dim TreeNode56 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Identificador :")
        Dim TreeNode57 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Data/Hora :")
        Dim TreeNode58 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Cam :")
        Dim TreeNode59 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Janelas :")
        Dim TreeNode60 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Pasta do Sistema :")
        Dim TreeNode61 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Idioma :")
        Dim TreeNode62 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("País :")
        Dim TreeNode63 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Tipo de Sistema :")
        Dim TreeNode64 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Medelo do Sistema :")
        Dim TreeNode65 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Versao/Data da BIOS :")
        Dim TreeNode66 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações do Computador", New System.Windows.Forms.TreeNode() {TreeNode43, TreeNode44, TreeNode45, TreeNode46, TreeNode47, TreeNode48, TreeNode49, TreeNode50, TreeNode51, TreeNode52, TreeNode53, TreeNode54, TreeNode55, TreeNode56, TreeNode57, TreeNode58, TreeNode59, TreeNode60, TreeNode61, TreeNode62, TreeNode63, TreeNode64, TreeNode65})
        Dim TreeNode67 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Localização :")
        Dim TreeNode68 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Atributos :")
        Dim TreeNode69 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Diretório :")
        Dim TreeNode70 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Port :")
        Dim TreeNode71 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Host :")
        Dim TreeNode72 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Servidor :")
        Dim TreeNode73 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Data de Instalação :")
        Dim TreeNode74 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações do Servidor", New System.Windows.Forms.TreeNode() {TreeNode67, TreeNode68, TreeNode69, TreeNode70, TreeNode71, TreeNode72, TreeNode73})
        Dim TreeNode75 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IPV4 :")
        Dim TreeNode76 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("IP Local :")
        Dim TreeNode77 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Endereço MAC :")
        Dim TreeNode78 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Informações da Rede", New System.Windows.Forms.TreeNode() {TreeNode75, TreeNode76, TreeNode77})
        Dim TreeNode79 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Proprietário Registrado :")
        Dim TreeNode80 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Organização Registrada :")
        Dim TreeNode81 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Chave do Produto :")
        Dim TreeNode82 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("AntiVirus Instalado :")
        Dim TreeNode83 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Firewall :")
        Dim TreeNode84 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Outras informações", New System.Windows.Forms.TreeNode() {TreeNode79, TreeNode80, TreeNode81, TreeNode82, TreeNode83})
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmInformações))
        Me.TRInformações = New System.Windows.Forms.TreeView()
        Me.IM = New System.Windows.Forms.ImageList(Me.components)
        Me.PBProgress = New System.Windows.Forms.ProgressBar()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TRInformações
        '
        Me.TRInformações.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TRInformações.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TRInformações.ForeColor = System.Drawing.Color.White
        Me.TRInformações.ImageKey = "application-blue.png"
        Me.TRInformações.ImageList = Me.IM
        Me.TRInformações.Location = New System.Drawing.Point(12, 12)
        Me.TRInformações.Name = "TRInformações"
        TreeNode43.ImageKey = "132.png"
        TreeNode43.Name = "Knoten8"
        TreeNode43.Text = "Nome do Computador :"
        TreeNode44.ImageKey = "133.png"
        TreeNode44.Name = "Knoten10"
        TreeNode44.Text = "Nome do Domínio :"
        TreeNode45.ImageKey = "134.png"
        TreeNode45.Name = "Knoten11"
        TreeNode45.Text = "Nome de Usuário :"
        TreeNode46.ImageKey = "135.png"
        TreeNode46.Name = "Knoten12"
        TreeNode46.Text = "Monitors :"
        TreeNode47.ImageKey = "136.png"
        TreeNode47.Name = "Knoten13"
        TreeNode47.Text = "Resolução :"
        TreeNode48.ImageKey = "137.png"
        TreeNode48.Name = "Knoten15"
        TreeNode48.Text = "Sistema Operacional :"
        TreeNode49.ImageKey = "138.png"
        TreeNode49.Name = "Knoten16"
        TreeNode49.Text = "Plataforma do Sistema :"
        TreeNode50.ImageKey = "139.png"
        TreeNode50.Name = "Knoten17"
        TreeNode50.Text = "Versão do Sistema :"
        TreeNode51.ImageKey = "140.png"
        TreeNode51.Name = "Knoten18"
        TreeNode51.Text = "RAM :"
        TreeNode52.ImageKey = "141.png"
        TreeNode52.Name = "Knoten19"
        TreeNode52.Text = "Bateria :"
        TreeNode53.ImageKey = "142.png"
        TreeNode53.Name = "Knoten21"
        TreeNode53.Text = "Informações CPU :"
        TreeNode54.ImageKey = "144.png"
        TreeNode54.Name = "Knoten22"
        TreeNode54.Text = "Informações GPU :"
        TreeNode55.ImageKey = "146.png"
        TreeNode55.Name = "Knoten23"
        TreeNode55.Text = "UpTime :"
        TreeNode56.ImageKey = "147.png"
        TreeNode56.Name = "Node0"
        TreeNode56.Text = "Identificador :"
        TreeNode57.ImageKey = "148.png"
        TreeNode57.Name = "Node7"
        TreeNode57.Text = "Data/Hora :"
        TreeNode58.ImageKey = "149.png"
        TreeNode58.Name = "Node8"
        TreeNode58.Text = "Cam :"
        TreeNode59.ImageKey = "150.png"
        TreeNode59.Name = "Node10"
        TreeNode59.Text = "Janelas :"
        TreeNode60.ImageKey = "151.png"
        TreeNode60.Name = "Node11"
        TreeNode60.Text = "Pasta do Sistema :"
        TreeNode61.ImageKey = "152.png"
        TreeNode61.Name = "Node12"
        TreeNode61.Text = "Idioma :"
        TreeNode62.ImageKey = "153.png"
        TreeNode62.Name = "Node16"
        TreeNode62.Text = "País :"
        TreeNode63.ImageKey = "154.png"
        TreeNode63.Name = "Node13"
        TreeNode63.Text = "Tipo de Sistema :"
        TreeNode64.ImageKey = "155.png"
        TreeNode64.Name = "Node14"
        TreeNode64.Text = "Medelo do Sistema :"
        TreeNode65.ImageKey = "156.png"
        TreeNode65.Name = "Node15"
        TreeNode65.Text = "Versao/Data da BIOS :"
        TreeNode66.ImageKey = "157.png"
        TreeNode66.Name = "Node12"
        TreeNode66.Text = "Informações do Computador"
        TreeNode67.ImageKey = "120.png"
        TreeNode67.Name = "Knoten1"
        TreeNode67.SelectedImageIndex = 1
        TreeNode67.Text = "Localização :"
        TreeNode68.ImageKey = "121.png"
        TreeNode68.Name = "Knoten2"
        TreeNode68.SelectedImageIndex = 2
        TreeNode68.Text = "Atributos :"
        TreeNode69.ImageKey = "122.png"
        TreeNode69.Name = "Node1"
        TreeNode69.Text = "Diretório :"
        TreeNode70.ImageKey = "123.png"
        TreeNode70.Name = "Node2"
        TreeNode70.Text = "Port :"
        TreeNode71.ImageKey = "124.png"
        TreeNode71.Name = "Node3"
        TreeNode71.Text = "Host :"
        TreeNode72.ImageKey = "125.png"
        TreeNode72.Name = "Node4"
        TreeNode72.Text = "Servidor :"
        TreeNode73.ImageKey = "126.png"
        TreeNode73.Name = "Node5"
        TreeNode73.Text = "Data de Instalação :"
        TreeNode74.ImageKey = "118.png"
        TreeNode74.Name = "nodpr"
        TreeNode74.Text = "Informações do Servidor"
        TreeNode75.ImageKey = "128.png"
        TreeNode75.Name = "Knoten4"
        TreeNode75.Text = "IPV4 :"
        TreeNode76.ImageKey = "129.png"
        TreeNode76.Name = "Knoten5"
        TreeNode76.Text = "IP Local :"
        TreeNode77.ImageKey = "130.png"
        TreeNode77.Name = "Knoten6"
        TreeNode77.Text = "Endereço MAC :"
        TreeNode78.ImageKey = "127.png"
        TreeNode78.Name = "Node8"
        TreeNode78.Text = "Informações da Rede"
        TreeNode79.ImageKey = "158.png"
        TreeNode79.Name = "Knoten25"
        TreeNode79.Text = "Proprietário Registrado :"
        TreeNode80.ImageKey = "159.png"
        TreeNode80.Name = "Node2"
        TreeNode80.Text = "Organização Registrada :"
        TreeNode81.ImageKey = "160.png"
        TreeNode81.Name = "Knoten27"
        TreeNode81.Text = "Chave do Produto :"
        TreeNode82.ImageKey = "161.png"
        TreeNode82.Name = "Knoten28"
        TreeNode82.Text = "AntiVirus Instalado :"
        TreeNode83.ImageKey = "162.png"
        TreeNode83.Name = "Knoten0"
        TreeNode83.Text = "Firewall :"
        TreeNode84.ImageKey = "157.png"
        TreeNode84.Name = "Node26"
        TreeNode84.Text = "Outras informações"
        Me.TRInformações.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode66, TreeNode74, TreeNode78, TreeNode84})
        Me.TRInformações.SelectedImageIndex = 0
        Me.TRInformações.Size = New System.Drawing.Size(508, 293)
        Me.TRInformações.TabIndex = 3
        '
        'IM
        '
        Me.IM.ImageStream = CType(resources.GetObject("IM.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IM.TransparentColor = System.Drawing.Color.Transparent
        Me.IM.Images.SetKeyName(0, "118.png")
        Me.IM.Images.SetKeyName(1, "120.png")
        Me.IM.Images.SetKeyName(2, "121.png")
        Me.IM.Images.SetKeyName(3, "122.png")
        Me.IM.Images.SetKeyName(4, "123.png")
        Me.IM.Images.SetKeyName(5, "124.png")
        Me.IM.Images.SetKeyName(6, "125.png")
        Me.IM.Images.SetKeyName(7, "126.png")
        Me.IM.Images.SetKeyName(8, "127.png")
        Me.IM.Images.SetKeyName(9, "128.png")
        Me.IM.Images.SetKeyName(10, "129.png")
        Me.IM.Images.SetKeyName(11, "130.png")
        Me.IM.Images.SetKeyName(12, "131.png")
        Me.IM.Images.SetKeyName(13, "132.png")
        Me.IM.Images.SetKeyName(14, "133.png")
        Me.IM.Images.SetKeyName(15, "134.png")
        Me.IM.Images.SetKeyName(16, "135.png")
        Me.IM.Images.SetKeyName(17, "136.png")
        Me.IM.Images.SetKeyName(18, "137.png")
        Me.IM.Images.SetKeyName(19, "138.png")
        Me.IM.Images.SetKeyName(20, "139.png")
        Me.IM.Images.SetKeyName(21, "140.png")
        Me.IM.Images.SetKeyName(22, "141.png")
        Me.IM.Images.SetKeyName(23, "142.png")
        Me.IM.Images.SetKeyName(24, "144.png")
        Me.IM.Images.SetKeyName(25, "146.png")
        Me.IM.Images.SetKeyName(26, "147.png")
        Me.IM.Images.SetKeyName(27, "148.png")
        Me.IM.Images.SetKeyName(28, "149.png")
        Me.IM.Images.SetKeyName(29, "150.png")
        Me.IM.Images.SetKeyName(30, "151.png")
        Me.IM.Images.SetKeyName(31, "152.png")
        Me.IM.Images.SetKeyName(32, "153.png")
        Me.IM.Images.SetKeyName(33, "154.png")
        Me.IM.Images.SetKeyName(34, "155.png")
        Me.IM.Images.SetKeyName(35, "156.png")
        Me.IM.Images.SetKeyName(36, "157.png")
        Me.IM.Images.SetKeyName(37, "158.png")
        Me.IM.Images.SetKeyName(38, "159.png")
        Me.IM.Images.SetKeyName(39, "160.png")
        Me.IM.Images.SetKeyName(40, "161.png")
        Me.IM.Images.SetKeyName(41, "162.png")
        '
        'PBProgress
        '
        Me.PBProgress.Location = New System.Drawing.Point(95, 323)
        Me.PBProgress.Maximum = 38
        Me.PBProgress.Name = "PBProgress"
        Me.PBProgress.Size = New System.Drawing.Size(427, 13)
        Me.PBProgress.TabIndex = 2
        '
        'btnOK
        '
        Me.btnOK.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnOK.Font = New System.Drawing.Font("Franklin Gothic Medium", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOK.Location = New System.Drawing.Point(12, 311)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(77, 36)
        Me.btnOK.TabIndex = 1
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'FrmInformações
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(531, 352)
        Me.Controls.Add(Me.PBProgress)
        Me.Controls.Add(Me.TRInformações)
        Me.Controls.Add(Me.btnOK)
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FrmInformações"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Informações (Vítima)"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents IM As System.Windows.Forms.ImageList
    Friend WithEvents PBProgress As System.Windows.Forms.ProgressBar
    Friend WithEvents TRInformações As System.Windows.Forms.TreeView
End Class
