﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Dim ListViewItem13 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {""}, -1, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Empty, Nothing)
        Dim ListViewItem14 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {""}, 13, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem15 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {""}, 9, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem16 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 4, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem17 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 0, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem18 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 5, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem19 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 11, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem20 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 12, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem21 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 2, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem22 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 3, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem23 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 14, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Dim ListViewItem24 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem(New String() {" "}, 15, System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer)), System.Drawing.Color.Black, New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte)))
        Me.IMG2 = New System.Windows.Forms.ImageList(Me.components)
        Me.Timer1 = New System.Timers.Timer()
        Me.BottomToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.TopToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.RightToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.LeftToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.ContentPanel = New System.Windows.Forms.ToolStripContentPanel()
        Me.CM = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExecutarNormalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExecutarInvisívelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromLinkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScriptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebSiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BlockWebSiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenChatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComputerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromLINKToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromDISKToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UninstallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisconnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WebcamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegeditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeyloggerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SenhasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformaçõesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IMG = New System.Windows.Forms.ImageList(Me.components)
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ST = New System.Windows.Forms.StatusStrip()
        Me.ToolStripDropDownButton3 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.CriarServidorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServidorNormalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DownloadURLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServidorTestToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripDropDownButton4 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.CréditosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.PesonalizaçãoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripDropDownButton2 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.FragsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DesktopToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEL = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbPorts = New System.Windows.Forms.ToolStripStatusLabel()
        Me.IM3 = New System.Windows.Forms.ImageList(Me.components)
        Me.CMNotificação = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfiguraçõesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutoHide = New DevComponents.DotNetBar.DotNetBarManager(Me.components)
        Me.DockSite4 = New DevComponents.DotNetBar.DockSite()
        Me.DockSite1 = New DevComponents.DotNetBar.DockSite()
        Me.DockSite2 = New DevComponents.DotNetBar.DockSite()
        Me.Bar1 = New DevComponents.DotNetBar.Bar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelDockContainer1 = New DevComponents.DotNetBar.PanelDockContainer()
        Me.PicMineDesktop = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.CKMostrarDesktop = New System.Windows.Forms.CheckBox()
        Me.CKMostrarInformações = New System.Windows.Forms.CheckBox()
        Me.LVListInfoO = New Coringa.LV()
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DockContainerItem1 = New DevComponents.DotNetBar.DockContainerItem()
        Me.DockSite8 = New DevComponents.DotNetBar.DockSite()
        Me.DockSite5 = New DevComponents.DotNetBar.DockSite()
        Me.DockSite6 = New DevComponents.DotNetBar.DockSite()
        Me.DockSite7 = New DevComponents.DotNetBar.DockSite()
        Me.DockSite3 = New DevComponents.DotNetBar.DockSite()
        Me.L1 = New Coringa.LV()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AvançadoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BasicoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GerenciadorDeArquivosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.Timer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CM.SuspendLayout()
        Me.ST.SuspendLayout()
        Me.CMNotificação.SuspendLayout()
        Me.DockSite2.SuspendLayout()
        CType(Me.Bar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Bar1.SuspendLayout()
        Me.PanelDockContainer1.SuspendLayout()
        CType(Me.PicMineDesktop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IMG2
        '
        Me.IMG2.ImageStream = CType(resources.GetObject("IMG2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IMG2.TransparentColor = System.Drawing.Color.Transparent
        Me.IMG2.Images.SetKeyName(0, "X.png")
        Me.IMG2.Images.SetKeyName(1, "b.png")
        Me.IMG2.Images.SetKeyName(2, "ABW.png")
        Me.IMG2.Images.SetKeyName(3, "AFG.png")
        Me.IMG2.Images.SetKeyName(4, "AGO.png")
        Me.IMG2.Images.SetKeyName(5, "AIA.png")
        Me.IMG2.Images.SetKeyName(6, "ALA.png")
        Me.IMG2.Images.SetKeyName(7, "ALB.png")
        Me.IMG2.Images.SetKeyName(8, "AND.png")
        Me.IMG2.Images.SetKeyName(9, "ARE.png")
        Me.IMG2.Images.SetKeyName(10, "ARG.png")
        Me.IMG2.Images.SetKeyName(11, "ARM.png")
        Me.IMG2.Images.SetKeyName(12, "ASM.png")
        Me.IMG2.Images.SetKeyName(13, "ATF.png")
        Me.IMG2.Images.SetKeyName(14, "ATG.png")
        Me.IMG2.Images.SetKeyName(15, "AUS.png")
        Me.IMG2.Images.SetKeyName(16, "AUT.png")
        Me.IMG2.Images.SetKeyName(17, "AZE.png")
        Me.IMG2.Images.SetKeyName(18, "BDI.png")
        Me.IMG2.Images.SetKeyName(19, "BEL.png")
        Me.IMG2.Images.SetKeyName(20, "BEN.png")
        Me.IMG2.Images.SetKeyName(21, "BFA.png")
        Me.IMG2.Images.SetKeyName(22, "BGD.png")
        Me.IMG2.Images.SetKeyName(23, "BGR.png")
        Me.IMG2.Images.SetKeyName(24, "BHR.png")
        Me.IMG2.Images.SetKeyName(25, "BHS.png")
        Me.IMG2.Images.SetKeyName(26, "BIH.png")
        Me.IMG2.Images.SetKeyName(27, "BLR.png")
        Me.IMG2.Images.SetKeyName(28, "BLZ.png")
        Me.IMG2.Images.SetKeyName(29, "BMU.png")
        Me.IMG2.Images.SetKeyName(30, "BOL.png")
        Me.IMG2.Images.SetKeyName(31, "BRA.png")
        Me.IMG2.Images.SetKeyName(32, "BRB.png")
        Me.IMG2.Images.SetKeyName(33, "BRN.png")
        Me.IMG2.Images.SetKeyName(34, "BTN.png")
        Me.IMG2.Images.SetKeyName(35, "BVT.png")
        Me.IMG2.Images.SetKeyName(36, "BWA.png")
        Me.IMG2.Images.SetKeyName(37, "CAF.png")
        Me.IMG2.Images.SetKeyName(38, "CAN.png")
        Me.IMG2.Images.SetKeyName(39, "CCK.png")
        Me.IMG2.Images.SetKeyName(40, "CHE.png")
        Me.IMG2.Images.SetKeyName(41, "CHL.png")
        Me.IMG2.Images.SetKeyName(42, "CHN.png")
        Me.IMG2.Images.SetKeyName(43, "CIV.png")
        Me.IMG2.Images.SetKeyName(44, "CMR.png")
        Me.IMG2.Images.SetKeyName(45, "COD.png")
        Me.IMG2.Images.SetKeyName(46, "COG.png")
        Me.IMG2.Images.SetKeyName(47, "COK.png")
        Me.IMG2.Images.SetKeyName(48, "COL.png")
        Me.IMG2.Images.SetKeyName(49, "COM.png")
        Me.IMG2.Images.SetKeyName(50, "CPV.png")
        Me.IMG2.Images.SetKeyName(51, "CRI.png")
        Me.IMG2.Images.SetKeyName(52, "CUB.png")
        Me.IMG2.Images.SetKeyName(53, "CXR.png")
        Me.IMG2.Images.SetKeyName(54, "CYM.png")
        Me.IMG2.Images.SetKeyName(55, "CYP.png")
        Me.IMG2.Images.SetKeyName(56, "CZE.png")
        Me.IMG2.Images.SetKeyName(57, "DEU.png")
        Me.IMG2.Images.SetKeyName(58, "DJI.png")
        Me.IMG2.Images.SetKeyName(59, "DMA.png")
        Me.IMG2.Images.SetKeyName(60, "DNK.png")
        Me.IMG2.Images.SetKeyName(61, "DOM.png")
        Me.IMG2.Images.SetKeyName(62, "DZA.png")
        Me.IMG2.Images.SetKeyName(63, "ECU.png")
        Me.IMG2.Images.SetKeyName(64, "EGY.png")
        Me.IMG2.Images.SetKeyName(65, "ERI.png")
        Me.IMG2.Images.SetKeyName(66, "ESH.png")
        Me.IMG2.Images.SetKeyName(67, "ESP.png")
        Me.IMG2.Images.SetKeyName(68, "EST.png")
        Me.IMG2.Images.SetKeyName(69, "ETH.png")
        Me.IMG2.Images.SetKeyName(70, "FIN.png")
        Me.IMG2.Images.SetKeyName(71, "FJI.png")
        Me.IMG2.Images.SetKeyName(72, "FLK.png")
        Me.IMG2.Images.SetKeyName(73, "FRA.png")
        Me.IMG2.Images.SetKeyName(74, "FRO.png")
        Me.IMG2.Images.SetKeyName(75, "FSM.png")
        Me.IMG2.Images.SetKeyName(76, "GAB.png")
        Me.IMG2.Images.SetKeyName(77, "GBR.png")
        Me.IMG2.Images.SetKeyName(78, "GEO.png")
        Me.IMG2.Images.SetKeyName(79, "GHA.png")
        Me.IMG2.Images.SetKeyName(80, "GIB.png")
        Me.IMG2.Images.SetKeyName(81, "GIN.png")
        Me.IMG2.Images.SetKeyName(82, "GLP.png")
        Me.IMG2.Images.SetKeyName(83, "GMB.png")
        Me.IMG2.Images.SetKeyName(84, "GNB.png")
        Me.IMG2.Images.SetKeyName(85, "GNQ.png")
        Me.IMG2.Images.SetKeyName(86, "GRC.png")
        Me.IMG2.Images.SetKeyName(87, "GRD.png")
        Me.IMG2.Images.SetKeyName(88, "GRL.png")
        Me.IMG2.Images.SetKeyName(89, "GTM.png")
        Me.IMG2.Images.SetKeyName(90, "GUF.png")
        Me.IMG2.Images.SetKeyName(91, "GUM.png")
        Me.IMG2.Images.SetKeyName(92, "GUY.png")
        Me.IMG2.Images.SetKeyName(93, "HKG.png")
        Me.IMG2.Images.SetKeyName(94, "HMD.png")
        Me.IMG2.Images.SetKeyName(95, "HND.png")
        Me.IMG2.Images.SetKeyName(96, "HRV.png")
        Me.IMG2.Images.SetKeyName(97, "HTI.png")
        Me.IMG2.Images.SetKeyName(98, "HUN.png")
        Me.IMG2.Images.SetKeyName(99, "IDN.png")
        Me.IMG2.Images.SetKeyName(100, "IND.png")
        Me.IMG2.Images.SetKeyName(101, "IOT.png")
        Me.IMG2.Images.SetKeyName(102, "IRL.png")
        Me.IMG2.Images.SetKeyName(103, "IRN.png")
        Me.IMG2.Images.SetKeyName(104, "IRQ.png")
        Me.IMG2.Images.SetKeyName(105, "ISL.png")
        Me.IMG2.Images.SetKeyName(106, "ISR.png")
        Me.IMG2.Images.SetKeyName(107, "ITA.png")
        Me.IMG2.Images.SetKeyName(108, "JAM.png")
        Me.IMG2.Images.SetKeyName(109, "JOR.png")
        Me.IMG2.Images.SetKeyName(110, "JPN.png")
        Me.IMG2.Images.SetKeyName(111, "KAZ.png")
        Me.IMG2.Images.SetKeyName(112, "KEN.png")
        Me.IMG2.Images.SetKeyName(113, "KGZ.png")
        Me.IMG2.Images.SetKeyName(114, "KHM.png")
        Me.IMG2.Images.SetKeyName(115, "KIR.png")
        Me.IMG2.Images.SetKeyName(116, "KNA.png")
        Me.IMG2.Images.SetKeyName(117, "KOR.png")
        Me.IMG2.Images.SetKeyName(118, "KWT.png")
        Me.IMG2.Images.SetKeyName(119, "LAO.png")
        Me.IMG2.Images.SetKeyName(120, "LBN.png")
        Me.IMG2.Images.SetKeyName(121, "LBR.png")
        Me.IMG2.Images.SetKeyName(122, "LBY.png")
        Me.IMG2.Images.SetKeyName(123, "LCA.png")
        Me.IMG2.Images.SetKeyName(124, "LIE.png")
        Me.IMG2.Images.SetKeyName(125, "LKA.png")
        Me.IMG2.Images.SetKeyName(126, "LSO.png")
        Me.IMG2.Images.SetKeyName(127, "LTU.png")
        Me.IMG2.Images.SetKeyName(128, "LUX.png")
        Me.IMG2.Images.SetKeyName(129, "LVA.png")
        Me.IMG2.Images.SetKeyName(130, "MAC.png")
        Me.IMG2.Images.SetKeyName(131, "MAR.png")
        Me.IMG2.Images.SetKeyName(132, "MCO.png")
        Me.IMG2.Images.SetKeyName(133, "MDA.png")
        Me.IMG2.Images.SetKeyName(134, "MDG.png")
        Me.IMG2.Images.SetKeyName(135, "MDV.png")
        Me.IMG2.Images.SetKeyName(136, "MEX.png")
        Me.IMG2.Images.SetKeyName(137, "MHL.png")
        Me.IMG2.Images.SetKeyName(138, "MKD.png")
        Me.IMG2.Images.SetKeyName(139, "MLI.png")
        Me.IMG2.Images.SetKeyName(140, "MLT.png")
        Me.IMG2.Images.SetKeyName(141, "MMR.png")
        Me.IMG2.Images.SetKeyName(142, "MNE.png")
        Me.IMG2.Images.SetKeyName(143, "MNG.png")
        Me.IMG2.Images.SetKeyName(144, "MNP.png")
        Me.IMG2.Images.SetKeyName(145, "MOZ.png")
        Me.IMG2.Images.SetKeyName(146, "MRT.png")
        Me.IMG2.Images.SetKeyName(147, "MSR.png")
        Me.IMG2.Images.SetKeyName(148, "MTQ.png")
        Me.IMG2.Images.SetKeyName(149, "MUS.png")
        Me.IMG2.Images.SetKeyName(150, "MWI.png")
        Me.IMG2.Images.SetKeyName(151, "MYS.png")
        Me.IMG2.Images.SetKeyName(152, "MYT.png")
        Me.IMG2.Images.SetKeyName(153, "NAM.png")
        Me.IMG2.Images.SetKeyName(154, "NCL.png")
        Me.IMG2.Images.SetKeyName(155, "NER.png")
        Me.IMG2.Images.SetKeyName(156, "NFK.png")
        Me.IMG2.Images.SetKeyName(157, "NGA.png")
        Me.IMG2.Images.SetKeyName(158, "NIC.png")
        Me.IMG2.Images.SetKeyName(159, "NIU.png")
        Me.IMG2.Images.SetKeyName(160, "NLD.png")
        Me.IMG2.Images.SetKeyName(161, "NOR.png")
        Me.IMG2.Images.SetKeyName(162, "NPL.png")
        Me.IMG2.Images.SetKeyName(163, "NRU.png")
        Me.IMG2.Images.SetKeyName(164, "NZL.png")
        Me.IMG2.Images.SetKeyName(165, "OMN.png")
        Me.IMG2.Images.SetKeyName(166, "PAK.png")
        Me.IMG2.Images.SetKeyName(167, "PAN.png")
        Me.IMG2.Images.SetKeyName(168, "PCN.png")
        Me.IMG2.Images.SetKeyName(169, "PER.png")
        Me.IMG2.Images.SetKeyName(170, "PHL.png")
        Me.IMG2.Images.SetKeyName(171, "PLW.png")
        Me.IMG2.Images.SetKeyName(172, "PNG.png")
        Me.IMG2.Images.SetKeyName(173, "POL.png")
        Me.IMG2.Images.SetKeyName(174, "PRI.png")
        Me.IMG2.Images.SetKeyName(175, "PRK.png")
        Me.IMG2.Images.SetKeyName(176, "PRT.png")
        Me.IMG2.Images.SetKeyName(177, "PRY.png")
        Me.IMG2.Images.SetKeyName(178, "PSE.png")
        Me.IMG2.Images.SetKeyName(179, "PYF.png")
        Me.IMG2.Images.SetKeyName(180, "QAT.png")
        Me.IMG2.Images.SetKeyName(181, "REU.png")
        Me.IMG2.Images.SetKeyName(182, "ROM.png")
        Me.IMG2.Images.SetKeyName(183, "RUS.png")
        Me.IMG2.Images.SetKeyName(184, "RWA.png")
        Me.IMG2.Images.SetKeyName(185, "SAU.png")
        Me.IMG2.Images.SetKeyName(186, "SDN.png")
        Me.IMG2.Images.SetKeyName(187, "SEN.png")
        Me.IMG2.Images.SetKeyName(188, "SGP.png")
        Me.IMG2.Images.SetKeyName(189, "SGS.png")
        Me.IMG2.Images.SetKeyName(190, "SHN.png")
        Me.IMG2.Images.SetKeyName(191, "SJM.png")
        Me.IMG2.Images.SetKeyName(192, "SLB.png")
        Me.IMG2.Images.SetKeyName(193, "SLE.png")
        Me.IMG2.Images.SetKeyName(194, "SLV.png")
        Me.IMG2.Images.SetKeyName(195, "SMR.png")
        Me.IMG2.Images.SetKeyName(196, "SOM.png")
        Me.IMG2.Images.SetKeyName(197, "SPM.png")
        Me.IMG2.Images.SetKeyName(198, "SRB.png")
        Me.IMG2.Images.SetKeyName(199, "STP.png")
        Me.IMG2.Images.SetKeyName(200, "SUR.png")
        Me.IMG2.Images.SetKeyName(201, "SVK.png")
        Me.IMG2.Images.SetKeyName(202, "SVN.png")
        Me.IMG2.Images.SetKeyName(203, "SWE.png")
        Me.IMG2.Images.SetKeyName(204, "SWZ.png")
        Me.IMG2.Images.SetKeyName(205, "SYC.png")
        Me.IMG2.Images.SetKeyName(206, "SYR.png")
        Me.IMG2.Images.SetKeyName(207, "TCA.png")
        Me.IMG2.Images.SetKeyName(208, "TCD.png")
        Me.IMG2.Images.SetKeyName(209, "TGO.png")
        Me.IMG2.Images.SetKeyName(210, "THA.png")
        Me.IMG2.Images.SetKeyName(211, "TJK.png")
        Me.IMG2.Images.SetKeyName(212, "TKL.png")
        Me.IMG2.Images.SetKeyName(213, "TKM.png")
        Me.IMG2.Images.SetKeyName(214, "TLS.png")
        Me.IMG2.Images.SetKeyName(215, "TON.png")
        Me.IMG2.Images.SetKeyName(216, "TTO.png")
        Me.IMG2.Images.SetKeyName(217, "TUN.png")
        Me.IMG2.Images.SetKeyName(218, "TUR.png")
        Me.IMG2.Images.SetKeyName(219, "TUV.png")
        Me.IMG2.Images.SetKeyName(220, "TWN.png")
        Me.IMG2.Images.SetKeyName(221, "TZA.png")
        Me.IMG2.Images.SetKeyName(222, "UGA.png")
        Me.IMG2.Images.SetKeyName(223, "UKR.png")
        Me.IMG2.Images.SetKeyName(224, "UMI.png")
        Me.IMG2.Images.SetKeyName(225, "URY.png")
        Me.IMG2.Images.SetKeyName(226, "USA.png")
        Me.IMG2.Images.SetKeyName(227, "UZB.png")
        Me.IMG2.Images.SetKeyName(228, "VAT.png")
        Me.IMG2.Images.SetKeyName(229, "VCT.png")
        Me.IMG2.Images.SetKeyName(230, "VEN.png")
        Me.IMG2.Images.SetKeyName(231, "VGB.png")
        Me.IMG2.Images.SetKeyName(232, "VIR.png")
        Me.IMG2.Images.SetKeyName(233, "VNM.png")
        Me.IMG2.Images.SetKeyName(234, "VUT.png")
        Me.IMG2.Images.SetKeyName(235, "WLF.png")
        Me.IMG2.Images.SetKeyName(236, "WSM.png")
        Me.IMG2.Images.SetKeyName(237, "YEM.png")
        Me.IMG2.Images.SetKeyName(238, "ZAF.png")
        Me.IMG2.Images.SetKeyName(239, "ZMB.png")
        Me.IMG2.Images.SetKeyName(240, "ZWE.png")
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.SynchronizingObject = Me
        '
        'BottomToolStripPanel
        '
        Me.BottomToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.BottomToolStripPanel.Name = "BottomToolStripPanel"
        Me.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.BottomToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.BottomToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'TopToolStripPanel
        '
        Me.TopToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.TopToolStripPanel.Name = "TopToolStripPanel"
        Me.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.TopToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.TopToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'RightToolStripPanel
        '
        Me.RightToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.RightToolStripPanel.Name = "RightToolStripPanel"
        Me.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.RightToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.RightToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'LeftToolStripPanel
        '
        Me.LeftToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.LeftToolStripPanel.Name = "LeftToolStripPanel"
        Me.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.LeftToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.LeftToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'ContentPanel
        '
        Me.ContentPanel.AutoScroll = True
        Me.ContentPanel.Size = New System.Drawing.Size(812, 255)
        '
        'CM
        '
        Me.CM.BackColor = System.Drawing.Color.Black
        Me.CM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.CM.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CM.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem6, Me.ToolStripMenuItem11, Me.ToolStripMenuItem10, Me.GerenciadorDeArquivosToolStripMenuItem, Me.RunFileToolStripMenuItem, Me.ToolStripMenuItem9, Me.SpToolStripMenuItem, Me.OpenChatToolStripMenuItem, Me.ToolStripMenuItem12, Me.ToolStripMenuItem13, Me.ComputerToolStripMenuItem, Me.ToolStripMenuItem5, Me.WebSiteToolStripMenuItem, Me.WebcamToolStripMenuItem, Me.ServerToolStripMenuItem, Me.CMDToolStripMenuItem, Me.RegeditToolStripMenuItem, Me.KeyloggerToolStripMenuItem, Me.SenhasToolStripMenuItem, Me.ToolStripMenuItem2, Me.InformaçõesToolStripMenuItem})
        Me.CM.Name = "ContextMenuStrip1"
        Me.CM.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.CM.Size = New System.Drawing.Size(243, 488)
        '
        'SpToolStripMenuItem
        '
        Me.SpToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.SpToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.SpToolStripMenuItem.Image = CType(resources.GetObject("SpToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SpToolStripMenuItem.Name = "SpToolStripMenuItem"
        Me.SpToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.SpToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.SpToolStripMenuItem.Text = "Adicionar Disco"
        '
        'RunFileToolStripMenuItem
        '
        Me.RunFileToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RunFileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExecutarNormalToolStripMenuItem, Me.ExecutarInvisívelToolStripMenuItem, Me.FromLinkToolStripMenuItem, Me.ScriptToolStripMenuItem})
        Me.RunFileToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RunFileToolStripMenuItem.Image = CType(resources.GetObject("RunFileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RunFileToolStripMenuItem.Name = "RunFileToolStripMenuItem"
        Me.RunFileToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.RunFileToolStripMenuItem.Text = "Executar Arquivos"
        '
        'ExecutarNormalToolStripMenuItem
        '
        Me.ExecutarNormalToolStripMenuItem.Name = "ExecutarNormalToolStripMenuItem"
        Me.ExecutarNormalToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExecutarNormalToolStripMenuItem.Text = "Executar Normal"
        '
        'ExecutarInvisívelToolStripMenuItem
        '
        Me.ExecutarInvisívelToolStripMenuItem.Name = "ExecutarInvisívelToolStripMenuItem"
        Me.ExecutarInvisívelToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExecutarInvisívelToolStripMenuItem.Text = "Executar Invisível"
        '
        'FromLinkToolStripMenuItem
        '
        Me.FromLinkToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.FromLinkToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FromLinkToolStripMenuItem.Name = "FromLinkToolStripMenuItem"
        Me.FromLinkToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.FromLinkToolStripMenuItem.Text = "URL"
        '
        'ScriptToolStripMenuItem
        '
        Me.ScriptToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.ScriptToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ScriptToolStripMenuItem.Name = "ScriptToolStripMenuItem"
        Me.ScriptToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ScriptToolStripMenuItem.Text = "Scrypt"
        '
        'WebSiteToolStripMenuItem
        '
        Me.WebSiteToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.WebSiteToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.BlockWebSiteToolStripMenuItem})
        Me.WebSiteToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.WebSiteToolStripMenuItem.Image = CType(resources.GetObject("WebSiteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WebSiteToolStripMenuItem.Name = "WebSiteToolStripMenuItem"
        Me.WebSiteToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.WebSiteToolStripMenuItem.Text = "WebSite"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.BackColor = System.Drawing.Color.White
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.ToolStripMenuItem1.Text = "Abrir WebSite"
        '
        'BlockWebSiteToolStripMenuItem
        '
        Me.BlockWebSiteToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.BlockWebSiteToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.BlockWebSiteToolStripMenuItem.Name = "BlockWebSiteToolStripMenuItem"
        Me.BlockWebSiteToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.BlockWebSiteToolStripMenuItem.Text = "Block WebSite"
        '
        'OpenChatToolStripMenuItem
        '
        Me.OpenChatToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.OpenChatToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.OpenChatToolStripMenuItem.Image = CType(resources.GetObject("OpenChatToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenChatToolStripMenuItem.Name = "OpenChatToolStripMenuItem"
        Me.OpenChatToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.OpenChatToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.OpenChatToolStripMenuItem.Text = "Bate-Papo"
        '
        'ComputerToolStripMenuItem
        '
        Me.ComputerToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ComputerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem3, Me.ShutdownToolStripMenuItem})
        Me.ComputerToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ComputerToolStripMenuItem.Image = CType(resources.GetObject("ComputerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ComputerToolStripMenuItem.Name = "ComputerToolStripMenuItem"
        Me.ComputerToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.ComputerToolStripMenuItem.Text = "Computador"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.BackColor = System.Drawing.Color.White
        Me.ToolStripMenuItem3.ForeColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(180, 22)
        Me.ToolStripMenuItem3.Text = "Reiniciar"
        '
        'ShutdownToolStripMenuItem
        '
        Me.ShutdownToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.ShutdownToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.ShutdownToolStripMenuItem.Name = "ShutdownToolStripMenuItem"
        Me.ShutdownToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ShutdownToolStripMenuItem.Text = "Desligar"
        '
        'ServerToolStripMenuItem
        '
        Me.ServerToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ServerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateToolStripMenuItem, Me.UninstallToolStripMenuItem, Me.RestartToolStripMenuItem, Me.CloseToolStripMenuItem, Me.DisconnectToolStripMenuItem})
        Me.ServerToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ServerToolStripMenuItem.Image = CType(resources.GetObject("ServerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ServerToolStripMenuItem.Name = "ServerToolStripMenuItem"
        Me.ServerToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.ServerToolStripMenuItem.Text = "Servidor"
        '
        'UpdateToolStripMenuItem
        '
        Me.UpdateToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.UpdateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FromLINKToolStripMenuItem1, Me.FromDISKToolStripMenuItem1})
        Me.UpdateToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem"
        Me.UpdateToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.UpdateToolStripMenuItem.Text = "Atualização"
        '
        'FromLINKToolStripMenuItem1
        '
        Me.FromLINKToolStripMenuItem1.BackColor = System.Drawing.Color.White
        Me.FromLINKToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.FromLINKToolStripMenuItem1.Name = "FromLINKToolStripMenuItem1"
        Me.FromLINKToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.FromLINKToolStripMenuItem1.Text = "URL"
        '
        'FromDISKToolStripMenuItem1
        '
        Me.FromDISKToolStripMenuItem1.BackColor = System.Drawing.Color.White
        Me.FromDISKToolStripMenuItem1.ForeColor = System.Drawing.Color.Black
        Me.FromDISKToolStripMenuItem1.Name = "FromDISKToolStripMenuItem1"
        Me.FromDISKToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.FromDISKToolStripMenuItem1.Text = "Disco Local"
        '
        'UninstallToolStripMenuItem
        '
        Me.UninstallToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.UninstallToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.UninstallToolStripMenuItem.Name = "UninstallToolStripMenuItem"
        Me.UninstallToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.UninstallToolStripMenuItem.Text = "Desinstalar"
        '
        'RestartToolStripMenuItem
        '
        Me.RestartToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.RestartToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.RestartToolStripMenuItem.Name = "RestartToolStripMenuItem"
        Me.RestartToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.RestartToolStripMenuItem.Text = "Reiniciar"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.CloseToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CloseToolStripMenuItem.Text = "Fechar"
        '
        'DisconnectToolStripMenuItem
        '
        Me.DisconnectToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.DisconnectToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.DisconnectToolStripMenuItem.Name = "DisconnectToolStripMenuItem"
        Me.DisconnectToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DisconnectToolStripMenuItem.Text = "Disconectar"
        '
        'WebcamToolStripMenuItem
        '
        Me.WebcamToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.WebcamToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.WebcamToolStripMenuItem.Image = CType(resources.GetObject("WebcamToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WebcamToolStripMenuItem.Name = "WebcamToolStripMenuItem"
        Me.WebcamToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.WebcamToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.WebcamToolStripMenuItem.Text = "Webcam"
        '
        'CMDToolStripMenuItem
        '
        Me.CMDToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.CMDToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.CMDToolStripMenuItem.Image = CType(resources.GetObject("CMDToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CMDToolStripMenuItem.Name = "CMDToolStripMenuItem"
        Me.CMDToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.J), System.Windows.Forms.Keys)
        Me.CMDToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.CMDToolStripMenuItem.Text = "CMD"
        '
        'RegeditToolStripMenuItem
        '
        Me.RegeditToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RegeditToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RegeditToolStripMenuItem.Image = CType(resources.GetObject("RegeditToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RegeditToolStripMenuItem.Name = "RegeditToolStripMenuItem"
        Me.RegeditToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.K), System.Windows.Forms.Keys)
        Me.RegeditToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.RegeditToolStripMenuItem.Text = "Regedit"
        '
        'KeyloggerToolStripMenuItem
        '
        Me.KeyloggerToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.KeyloggerToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.KeyloggerToolStripMenuItem.Image = CType(resources.GetObject("KeyloggerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.KeyloggerToolStripMenuItem.Name = "KeyloggerToolStripMenuItem"
        Me.KeyloggerToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.KeyloggerToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.KeyloggerToolStripMenuItem.Text = "Keylogger"
        '
        'SenhasToolStripMenuItem
        '
        Me.SenhasToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.SenhasToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.SenhasToolStripMenuItem.Image = CType(resources.GetObject("SenhasToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SenhasToolStripMenuItem.Name = "SenhasToolStripMenuItem"
        Me.SenhasToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.SenhasToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.SenhasToolStripMenuItem.Text = "Senhas"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.BackColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem2.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem2.Image = CType(resources.GetObject("ToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem2.Text = "Abrir Pasta"
        '
        'InformaçõesToolStripMenuItem
        '
        Me.InformaçõesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.InformaçõesToolStripMenuItem.Image = CType(resources.GetObject("InformaçõesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.InformaçõesToolStripMenuItem.Name = "InformaçõesToolStripMenuItem"
        Me.InformaçõesToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.InformaçõesToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.InformaçõesToolStripMenuItem.Text = "Informações"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ToolStripMenuItem5.Image = CType(resources.GetObject("ToolStripMenuItem5.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem5.Text = "Listar Janelas"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem7, Me.ToolStripMenuItem8})
        Me.ToolStripMenuItem6.ForeColor = System.Drawing.SystemColors.Control
        Me.ToolStripMenuItem6.Image = CType(resources.GetObject("ToolStripMenuItem6.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem6.Text = "Área de Trabalho"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(180, 22)
        Me.ToolStripMenuItem7.Text = "Desktop-01"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(180, 22)
        Me.ToolStripMenuItem8.Text = "Desktop-02"
        '
        'IMG
        '
        Me.IMG.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.IMG.ImageSize = New System.Drawing.Size(24, 24)
        Me.IMG.TransparentColor = System.Drawing.Color.Transparent
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(0, 17)
        '
        'ST
        '
        Me.ST.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ST.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ST.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel5, Me.ToolStripDropDownButton3, Me.ToolStripDropDownButton4, Me.ToolStripDropDownButton1, Me.ToolStripDropDownButton2, Me.SEL, Me.lbPorts})
        Me.ST.Location = New System.Drawing.Point(0, 449)
        Me.ST.Name = "ST"
        Me.ST.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ST.Size = New System.Drawing.Size(941, 22)
        Me.ST.SizingGrip = False
        Me.ST.TabIndex = 0
        '
        'ToolStripDropDownButton3
        '
        Me.ToolStripDropDownButton3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CriarServidorToolStripMenuItem})
        Me.ToolStripDropDownButton3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ToolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton3.Name = "ToolStripDropDownButton3"
        Me.ToolStripDropDownButton3.Size = New System.Drawing.Size(63, 20)
        Me.ToolStripDropDownButton3.Text = "Servidor"
        Me.ToolStripDropDownButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'CriarServidorToolStripMenuItem
        '
        Me.CriarServidorToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CriarServidorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ServidorNormalToolStripMenuItem, Me.DownloadURLToolStripMenuItem, Me.ServidorTestToolStripMenuItem})
        Me.CriarServidorToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.CriarServidorToolStripMenuItem.Name = "CriarServidorToolStripMenuItem"
        Me.CriarServidorToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.CriarServidorToolStripMenuItem.Text = "Servidor"
        Me.CriarServidorToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'ServidorNormalToolStripMenuItem
        '
        Me.ServidorNormalToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ServidorNormalToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ServidorNormalToolStripMenuItem.Name = "ServidorNormalToolStripMenuItem"
        Me.ServidorNormalToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ServidorNormalToolStripMenuItem.Text = "Servidor (Normal)"
        '
        'DownloadURLToolStripMenuItem
        '
        Me.DownloadURLToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DownloadURLToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.DownloadURLToolStripMenuItem.Name = "DownloadURLToolStripMenuItem"
        Me.DownloadURLToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.DownloadURLToolStripMenuItem.Text = "Download (URL)"
        '
        'ServidorTestToolStripMenuItem
        '
        Me.ServidorTestToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ServidorTestToolStripMenuItem.Enabled = False
        Me.ServidorTestToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ServidorTestToolStripMenuItem.Name = "ServidorTestToolStripMenuItem"
        Me.ServidorTestToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.ServidorTestToolStripMenuItem.Text = "Servidor (Test)"
        '
        'ToolStripDropDownButton4
        '
        Me.ToolStripDropDownButton4.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CréditosToolStripMenuItem})
        Me.ToolStripDropDownButton4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ToolStripDropDownButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton4.Name = "ToolStripDropDownButton4"
        Me.ToolStripDropDownButton4.Size = New System.Drawing.Size(84, 20)
        Me.ToolStripDropDownButton4.Text = "Informações"
        Me.ToolStripDropDownButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'CréditosToolStripMenuItem
        '
        Me.CréditosToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CréditosToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.CréditosToolStripMenuItem.Name = "CréditosToolStripMenuItem"
        Me.CréditosToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.CréditosToolStripMenuItem.Text = "Créditos"
        Me.CréditosToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PesonalizaçãoToolStripMenuItem})
        Me.ToolStripDropDownButton1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(95, 20)
        Me.ToolStripDropDownButton1.Text = "Configurações"
        '
        'PesonalizaçãoToolStripMenuItem
        '
        Me.PesonalizaçãoToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.PesonalizaçãoToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.PesonalizaçãoToolStripMenuItem.Name = "PesonalizaçãoToolStripMenuItem"
        Me.PesonalizaçãoToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.PesonalizaçãoToolStripMenuItem.Text = "Personalização"
        Me.PesonalizaçãoToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'ToolStripDropDownButton2
        '
        Me.ToolStripDropDownButton2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FragsToolStripMenuItem1, Me.DesktopToolStripMenuItem1})
        Me.ToolStripDropDownButton2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.ToolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton2.Name = "ToolStripDropDownButton2"
        Me.ToolStripDropDownButton2.Size = New System.Drawing.Size(69, 20)
        Me.ToolStripDropDownButton2.Text = "Visualizar"
        '
        'FragsToolStripMenuItem1
        '
        Me.FragsToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.FragsToolStripMenuItem1.Enabled = False
        Me.FragsToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.FragsToolStripMenuItem1.Name = "FragsToolStripMenuItem1"
        Me.FragsToolStripMenuItem1.Size = New System.Drawing.Size(117, 22)
        Me.FragsToolStripMenuItem1.Text = "Frags"
        Me.FragsToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'DesktopToolStripMenuItem1
        '
        Me.DesktopToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DesktopToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.DesktopToolStripMenuItem1.Name = "DesktopToolStripMenuItem1"
        Me.DesktopToolStripMenuItem1.Size = New System.Drawing.Size(117, 22)
        Me.DesktopToolStripMenuItem1.Text = "Desktop"
        Me.DesktopToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay
        '
        'SEL
        '
        Me.SEL.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SEL.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.SEL.Name = "SEL"
        Me.SEL.Size = New System.Drawing.Size(119, 17)
        Me.SEL.Text = "          Selecionados 0"
        '
        'lbPorts
        '
        Me.lbPorts.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.lbPorts.Name = "lbPorts"
        Me.lbPorts.Size = New System.Drawing.Size(215, 17)
        Me.lbPorts.Text = "          Aguardando Conexão nas Portas :"
        '
        'IM3
        '
        Me.IM3.ImageStream = CType(resources.GetObject("IM3.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IM3.TransparentColor = System.Drawing.Color.Transparent
        Me.IM3.Images.SetKeyName(0, "08.png")
        Me.IM3.Images.SetKeyName(1, "02.png")
        Me.IM3.Images.SetKeyName(2, "03.png")
        Me.IM3.Images.SetKeyName(3, "04.png")
        Me.IM3.Images.SetKeyName(4, "95.png")
        Me.IM3.Images.SetKeyName(5, "96.png")
        Me.IM3.Images.SetKeyName(6, "97.png")
        Me.IM3.Images.SetKeyName(7, "98.png")
        Me.IM3.Images.SetKeyName(8, "99.png")
        Me.IM3.Images.SetKeyName(9, "100.png")
        Me.IM3.Images.SetKeyName(10, "101.png")
        Me.IM3.Images.SetKeyName(11, "102.png")
        Me.IM3.Images.SetKeyName(12, "103.png")
        Me.IM3.Images.SetKeyName(13, "104.png")
        Me.IM3.Images.SetKeyName(14, "105.png")
        Me.IM3.Images.SetKeyName(15, "106.png")
        '
        'CMNotificação
        '
        Me.CMNotificação.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem4, Me.ConfiguraçõesToolStripMenuItem})
        Me.CMNotificação.Name = "CMNotificação"
        Me.CMNotificação.ShowImageMargin = False
        Me.CMNotificação.Size = New System.Drawing.Size(127, 48)
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(126, 22)
        Me.ToolStripMenuItem4.Text = "Informações"
        '
        'ConfiguraçõesToolStripMenuItem
        '
        Me.ConfiguraçõesToolStripMenuItem.Name = "ConfiguraçõesToolStripMenuItem"
        Me.ConfiguraçõesToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.ConfiguraçõesToolStripMenuItem.Text = "Configurações"
        '
        'AutoHide
        '
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.F1)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlC)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlA)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlV)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlX)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlZ)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlY)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.Del)
        Me.AutoHide.AutoDispatchShortcuts.Add(DevComponents.DotNetBar.eShortcut.Ins)
        Me.AutoHide.BottomDockSite = Me.DockSite4
        Me.AutoHide.ColorScheme.BarBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.BarBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.BarCaptionBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.BarCaptionBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.BarCaptionInactiveBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.BarCaptionInactiveBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.BarCaptionInactiveText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.BarCaptionText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.BarDockedBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.BarFloatingBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.BarPopupBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.BarPopupBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.BarStripeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.CustomizeBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.CustomizeBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.CustomizeText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.DockSiteBackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.DockSiteBackColor2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ExplorerBarBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ExplorerBarBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ExplorerBarBackgroundGradientAngle = 80
        Me.AutoHide.ColorScheme.ItemBackgroundGradientAngle = 80
        Me.AutoHide.ColorScheme.ItemCheckedBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemCheckedBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemCheckedBackgroundGradientAngle = 80
        Me.AutoHide.ColorScheme.ItemCheckedBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemCheckedText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemDesignTimeBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemDisabledText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemExpandedBackground = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemExpandedBackground2 = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemExpandedBackgroundGradientAngle = 80
        Me.AutoHide.ColorScheme.ItemExpandedBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemExpandedText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemHotBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemHotBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemHotBackgroundGradientAngle = 80
        Me.AutoHide.ColorScheme.ItemHotBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemHotText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemPressedBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemPressedBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemPressedBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemPressedText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemSeparator = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.ItemText = System.Drawing.Color.Black
        Me.AutoHide.ColorScheme.MenuBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuBarBackground = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuBarBackground2 = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuBarBackgroundGradientAngle = 80
        Me.AutoHide.ColorScheme.MenuBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuSide = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuSide2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuUnusedBackground = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuUnusedSide = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.MenuUnusedSide2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.PanelBackground = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.PanelBackground2 = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.AutoHide.ColorScheme.PanelBorder = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.PanelText = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.AutoHide.ColorScheme.SplitterBackground = System.Drawing.Color.Empty
        Me.AutoHide.ColorScheme.SplitterBackground2 = System.Drawing.Color.Empty
        Me.AutoHide.ColorScheme.SplitterBorder = System.Drawing.Color.Empty
        Me.AutoHide.EnableFullSizeDock = False
        Me.AutoHide.LeftDockSite = Me.DockSite1
        Me.AutoHide.ParentForm = Me
        Me.AutoHide.RightDockSite = Me.DockSite2
        Me.AutoHide.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003
        Me.AutoHide.ToolbarBottomDockSite = Me.DockSite8
        Me.AutoHide.ToolbarLeftDockSite = Me.DockSite5
        Me.AutoHide.ToolbarRightDockSite = Me.DockSite6
        Me.AutoHide.ToolbarTopDockSite = Me.DockSite7
        Me.AutoHide.TopDockSite = Me.DockSite3
        Me.AutoHide.UseGlobalColorScheme = True
        '
        'DockSite4
        '
        Me.DockSite4.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DockSite4.DocumentDockContainer = New DevComponents.DotNetBar.DocumentDockContainer()
        Me.DockSite4.Location = New System.Drawing.Point(0, 471)
        Me.DockSite4.Name = "DockSite4"
        Me.DockSite4.Size = New System.Drawing.Size(941, 0)
        Me.DockSite4.TabIndex = 13
        Me.DockSite4.TabStop = False
        '
        'DockSite1
        '
        Me.DockSite1.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite1.Dock = System.Windows.Forms.DockStyle.Left
        Me.DockSite1.DocumentDockContainer = New DevComponents.DotNetBar.DocumentDockContainer()
        Me.DockSite1.Location = New System.Drawing.Point(0, 0)
        Me.DockSite1.Name = "DockSite1"
        Me.DockSite1.Size = New System.Drawing.Size(0, 449)
        Me.DockSite1.TabIndex = 10
        Me.DockSite1.TabStop = False
        '
        'DockSite2
        '
        Me.DockSite2.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite2.Controls.Add(Me.Bar1)
        Me.DockSite2.Dock = System.Windows.Forms.DockStyle.Right
        Me.DockSite2.DocumentDockContainer = New DevComponents.DotNetBar.DocumentDockContainer(New DevComponents.DotNetBar.DocumentBaseContainer() {CType(New DevComponents.DotNetBar.DocumentBarContainer(Me.Bar1, 247, 449), DevComponents.DotNetBar.DocumentBaseContainer)}, DevComponents.DotNetBar.eOrientation.Horizontal)
        Me.DockSite2.Location = New System.Drawing.Point(691, 0)
        Me.DockSite2.Name = "DockSite2"
        Me.DockSite2.Size = New System.Drawing.Size(250, 449)
        Me.DockSite2.TabIndex = 11
        Me.DockSite2.TabStop = False
        '
        'Bar1
        '
        Me.Bar1.AccessibleDescription = "DotNetBar Bar (Bar1)"
        Me.Bar1.AccessibleName = "DotNetBar Bar"
        Me.Bar1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.Bar1.AutoSyncBarCaption = True
        Me.Bar1.BackColor = System.Drawing.Color.Black
        Me.Bar1.CloseSingleTab = True
        Me.Bar1.Controls.Add(Me.Label1)
        Me.Bar1.Controls.Add(Me.PanelDockContainer1)
        Me.Bar1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bar1.GrabHandleStyle = DevComponents.DotNetBar.eGrabHandleStyle.Caption
        Me.Bar1.Items.AddRange(New DevComponents.DotNetBar.BaseItem() {Me.DockContainerItem1})
        Me.Bar1.LayoutType = DevComponents.DotNetBar.eLayoutType.DockContainer
        Me.Bar1.Location = New System.Drawing.Point(3, 0)
        Me.Bar1.Name = "Bar1"
        Me.Bar1.Size = New System.Drawing.Size(247, 449)
        Me.Bar1.Stretch = True
        Me.Bar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2003
        Me.Bar1.TabIndex = 0
        Me.Bar1.TabStop = False
        Me.Bar1.Text = "DockContainerItem1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(4, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "                              "
        '
        'PanelDockContainer1
        '
        Me.PanelDockContainer1.Controls.Add(Me.PicMineDesktop)
        Me.PanelDockContainer1.Controls.Add(Me.PictureBox1)
        Me.PanelDockContainer1.Controls.Add(Me.Panel3)
        Me.PanelDockContainer1.Controls.Add(Me.Panel1)
        Me.PanelDockContainer1.DisabledBackColor = System.Drawing.Color.Empty
        Me.PanelDockContainer1.Location = New System.Drawing.Point(3, 23)
        Me.PanelDockContainer1.Name = "PanelDockContainer1"
        Me.PanelDockContainer1.Size = New System.Drawing.Size(241, 423)
        Me.PanelDockContainer1.Style.Alignment = System.Drawing.StringAlignment.Center
        Me.PanelDockContainer1.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground
        Me.PanelDockContainer1.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2
        Me.PanelDockContainer1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine
        Me.PanelDockContainer1.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder
        Me.PanelDockContainer1.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText
        Me.PanelDockContainer1.Style.GradientAngle = 90
        Me.PanelDockContainer1.StyleMouseDown.Alignment = System.Drawing.StringAlignment.Center
        Me.PanelDockContainer1.StyleMouseDown.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemPressedBackground
        Me.PanelDockContainer1.StyleMouseDown.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemPressedBackground2
        Me.PanelDockContainer1.StyleMouseDown.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemPressedBorder
        Me.PanelDockContainer1.StyleMouseDown.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemPressedText
        Me.PanelDockContainer1.StyleMouseOver.Alignment = System.Drawing.StringAlignment.Center
        Me.PanelDockContainer1.StyleMouseOver.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemHotBackground
        Me.PanelDockContainer1.StyleMouseOver.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemHotBackground2
        Me.PanelDockContainer1.StyleMouseOver.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemHotBorder
        Me.PanelDockContainer1.StyleMouseOver.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemHotText
        Me.PanelDockContainer1.TabIndex = 0
        Me.PanelDockContainer1.Visible = True
        '
        'PicMineDesktop
        '
        Me.PicMineDesktop.BackColor = System.Drawing.Color.Black
        Me.PicMineDesktop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PicMineDesktop.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PicMineDesktop.ErrorImage = CType(resources.GetObject("PicMineDesktop.ErrorImage"), System.Drawing.Image)
        Me.PicMineDesktop.Image = CType(resources.GetObject("PicMineDesktop.Image"), System.Drawing.Image)
        Me.PicMineDesktop.InitialImage = CType(resources.GetObject("PicMineDesktop.InitialImage"), System.Drawing.Image)
        Me.PicMineDesktop.Location = New System.Drawing.Point(0, 0)
        Me.PicMineDesktop.Name = "PicMineDesktop"
        Me.PicMineDesktop.Size = New System.Drawing.Size(241, 170)
        Me.PicMineDesktop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PicMineDesktop.TabIndex = 7
        Me.PicMineDesktop.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Black
        Me.PictureBox1.Location = New System.Drawing.Point(-6, -4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(252, 174)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Controls.Add(Me.CKMostrarDesktop)
        Me.Panel3.Controls.Add(Me.CKMostrarInformações)
        Me.Panel3.Controls.Add(Me.LVListInfoO)
        Me.Panel3.Location = New System.Drawing.Point(0, 170)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(246, 300)
        Me.Panel3.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(3, 49)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(235, 168)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = resources.GetString("Label4.Text")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Font = New System.Drawing.Font("Impact", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(10, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 16)
        Me.Label3.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Font = New System.Drawing.Font("Impact", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(32, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(177, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Ferramenta Para Anti Pedofilia"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox2.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(241, 253)
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'CKMostrarDesktop
        '
        Me.CKMostrarDesktop.AutoSize = True
        Me.CKMostrarDesktop.BackColor = System.Drawing.Color.Black
        Me.CKMostrarDesktop.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKMostrarDesktop.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CKMostrarDesktop.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.CKMostrarDesktop.Location = New System.Drawing.Point(57, 74)
        Me.CKMostrarDesktop.Name = "CKMostrarDesktop"
        Me.CKMostrarDesktop.Size = New System.Drawing.Size(137, 20)
        Me.CKMostrarDesktop.TabIndex = 4
        Me.CKMostrarDesktop.Text = "Área de Trabalho"
        Me.CKMostrarDesktop.UseVisualStyleBackColor = False
        '
        'CKMostrarInformações
        '
        Me.CKMostrarInformações.AutoSize = True
        Me.CKMostrarInformações.BackColor = System.Drawing.Color.Black
        Me.CKMostrarInformações.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CKMostrarInformações.Font = New System.Drawing.Font("Impact", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CKMostrarInformações.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.CKMostrarInformações.Location = New System.Drawing.Point(57, 100)
        Me.CKMostrarInformações.Name = "CKMostrarInformações"
        Me.CKMostrarInformações.Size = New System.Drawing.Size(97, 21)
        Me.CKMostrarInformações.TabIndex = 3
        Me.CKMostrarInformações.Text = "Informações"
        Me.CKMostrarInformações.UseVisualStyleBackColor = False
        '
        'LVListInfoO
        '
        Me.LVListInfoO.BackColor = System.Drawing.Color.Black
        Me.LVListInfoO.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.LVListInfoO.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader12})
        Me.LVListInfoO.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LVListInfoO.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LVListInfoO.ForeColor = System.Drawing.Color.White
        Me.LVListInfoO.FullRowSelect = True
        Me.LVListInfoO.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.LVListInfoO.HideSelection = False
        Me.LVListInfoO.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem13, ListViewItem14, ListViewItem15, ListViewItem16, ListViewItem17, ListViewItem18, ListViewItem19, ListViewItem20, ListViewItem21, ListViewItem22, ListViewItem23, ListViewItem24})
        Me.LVListInfoO.Location = New System.Drawing.Point(0, 0)
        Me.LVListInfoO.MultiSelect = False
        Me.LVListInfoO.Name = "LVListInfoO"
        Me.LVListInfoO.Scrollable = False
        Me.LVListInfoO.ShowGroups = False
        Me.LVListInfoO.Size = New System.Drawing.Size(246, 300)
        Me.LVListInfoO.SmallImageList = Me.IM3
        Me.LVListInfoO.TabIndex = 2
        Me.LVListInfoO.UseCompatibleStateImageBehavior = False
        Me.LVListInfoO.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader12
        '
        Me.ColumnHeader12.Width = 400
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.ForeColor = System.Drawing.Color.Transparent
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(241, 423)
        Me.Panel1.TabIndex = 5
        '
        'DockContainerItem1
        '
        Me.DockContainerItem1.Control = Me.PanelDockContainer1
        Me.DockContainerItem1.Name = "DockContainerItem1"
        Me.DockContainerItem1.Text = "DockContainerItem1"
        '
        'DockSite8
        '
        Me.DockSite8.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite8.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.DockSite8.Location = New System.Drawing.Point(0, 471)
        Me.DockSite8.Name = "DockSite8"
        Me.DockSite8.Size = New System.Drawing.Size(941, 0)
        Me.DockSite8.TabIndex = 17
        Me.DockSite8.TabStop = False
        '
        'DockSite5
        '
        Me.DockSite5.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite5.Dock = System.Windows.Forms.DockStyle.Left
        Me.DockSite5.Location = New System.Drawing.Point(0, 0)
        Me.DockSite5.Name = "DockSite5"
        Me.DockSite5.Size = New System.Drawing.Size(0, 471)
        Me.DockSite5.TabIndex = 14
        Me.DockSite5.TabStop = False
        '
        'DockSite6
        '
        Me.DockSite6.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite6.Dock = System.Windows.Forms.DockStyle.Right
        Me.DockSite6.Location = New System.Drawing.Point(941, 0)
        Me.DockSite6.Name = "DockSite6"
        Me.DockSite6.Size = New System.Drawing.Size(0, 471)
        Me.DockSite6.TabIndex = 15
        Me.DockSite6.TabStop = False
        '
        'DockSite7
        '
        Me.DockSite7.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite7.Dock = System.Windows.Forms.DockStyle.Top
        Me.DockSite7.Location = New System.Drawing.Point(0, 0)
        Me.DockSite7.Name = "DockSite7"
        Me.DockSite7.Size = New System.Drawing.Size(941, 0)
        Me.DockSite7.TabIndex = 16
        Me.DockSite7.TabStop = False
        '
        'DockSite3
        '
        Me.DockSite3.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.DockSite3.Dock = System.Windows.Forms.DockStyle.Top
        Me.DockSite3.DocumentDockContainer = New DevComponents.DotNetBar.DocumentDockContainer()
        Me.DockSite3.Location = New System.Drawing.Point(0, 0)
        Me.DockSite3.Name = "DockSite3"
        Me.DockSite3.Size = New System.Drawing.Size(941, 0)
        Me.DockSite3.TabIndex = 12
        Me.DockSite3.TabStop = False
        '
        'L1
        '
        Me.L1.BackColor = System.Drawing.Color.White
        Me.L1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.L1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10, Me.ColumnHeader11})
        Me.L1.ContextMenuStrip = Me.CM
        Me.L1.Cursor = System.Windows.Forms.Cursors.Default
        Me.L1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.L1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.L1.FullRowSelect = True
        Me.L1.GridLines = True
        Me.L1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.L1.HideSelection = False
        Me.L1.LargeImageList = Me.IMG2
        Me.L1.Location = New System.Drawing.Point(0, 0)
        Me.L1.Name = "L1"
        Me.L1.Size = New System.Drawing.Size(691, 449)
        Me.L1.SmallImageList = Me.IMG2
        Me.L1.TabIndex = 0
        Me.L1.TileSize = New System.Drawing.Size(266, 38)
        Me.L1.UseCompatibleStateImageBehavior = False
        Me.L1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Nome"
        Me.ColumnHeader1.Width = 70
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "IP/Host"
        Me.ColumnHeader2.Width = 49
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "PC"
        Me.ColumnHeader3.Width = 42
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Usuário"
        Me.ColumnHeader4.Width = 53
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Data de Instalação"
        Me.ColumnHeader5.Width = 107
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "País"
        Me.ColumnHeader6.Width = 64
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Sistema Operacional"
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "Webcam"
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Versão"
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Ping"
        '
        'ColumnHeader11
        '
        Me.ColumnHeader11.Text = "Janelas"
        Me.ColumnHeader11.Width = 76
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ToolStripMenuItem9.Image = CType(resources.GetObject("ToolStripMenuItem9.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem9.Text = "StartUp Manager"
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem10.Image = CType(resources.GetObject("ToolStripMenuItem10.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem10.Text = "Programas Instalados"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ToolStripMenuItem11.Image = CType(resources.GetObject("ToolStripMenuItem11.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem11.Text = "Gerenciador de Tarefas"
        '
        'ToolStripMenuItem12
        '
        Me.ToolStripMenuItem12.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ToolStripMenuItem12.Image = CType(resources.GetObject("ToolStripMenuItem12.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem12.Name = "ToolStripMenuItem12"
        Me.ToolStripMenuItem12.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.G), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem12.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem12.Text = "Enviar Mensagem"
        '
        'ToolStripMenuItem13
        '
        Me.ToolStripMenuItem13.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ToolStripMenuItem13.Image = CType(resources.GetObject("ToolStripMenuItem13.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem13.Name = "ToolStripMenuItem13"
        Me.ToolStripMenuItem13.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.H), System.Windows.Forms.Keys)
        Me.ToolStripMenuItem13.Size = New System.Drawing.Size(242, 22)
        Me.ToolStripMenuItem13.Text = "Listar Conexões"
        '
        'AvançadoToolStripMenuItem
        '
        Me.AvançadoToolStripMenuItem.Name = "AvançadoToolStripMenuItem"
        Me.AvançadoToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AvançadoToolStripMenuItem.Text = "Avançado"
        '
        'BasicoToolStripMenuItem
        '
        Me.BasicoToolStripMenuItem.Name = "BasicoToolStripMenuItem"
        Me.BasicoToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.BasicoToolStripMenuItem.Text = "Basico"
        '
        'GerenciadorDeArquivosToolStripMenuItem
        '
        Me.GerenciadorDeArquivosToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.GerenciadorDeArquivosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AvançadoToolStripMenuItem, Me.BasicoToolStripMenuItem})
        Me.GerenciadorDeArquivosToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.GerenciadorDeArquivosToolStripMenuItem.Image = CType(resources.GetObject("GerenciadorDeArquivosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GerenciadorDeArquivosToolStripMenuItem.Name = "GerenciadorDeArquivosToolStripMenuItem"
        Me.GerenciadorDeArquivosToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.GerenciadorDeArquivosToolStripMenuItem.Text = "Gerenciador de Arquivos"
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(941, 471)
        Me.Controls.Add(Me.L1)
        Me.Controls.Add(Me.DockSite2)
        Me.Controls.Add(Me.DockSite1)
        Me.Controls.Add(Me.ST)
        Me.Controls.Add(Me.DockSite3)
        Me.Controls.Add(Me.DockSite4)
        Me.Controls.Add(Me.DockSite5)
        Me.Controls.Add(Me.DockSite6)
        Me.Controls.Add(Me.DockSite7)
        Me.Controls.Add(Me.DockSite8)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FrmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PHAP"
        CType(Me.Timer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CM.ResumeLayout(False)
        Me.ST.ResumeLayout(False)
        Me.ST.PerformLayout()
        Me.CMNotificação.ResumeLayout(False)
        Me.DockSite2.ResumeLayout(False)
        CType(Me.Bar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Bar1.ResumeLayout(False)
        Me.Bar1.PerformLayout()
        Me.PanelDockContainer1.ResumeLayout(False)
        CType(Me.PicMineDesktop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Timers.Timer
    Friend WithEvents IMG2 As System.Windows.Forms.ImageList
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents LVListInfoO As Coringa.LV
    Friend WithEvents IMG As System.Windows.Forms.ImageList
    Friend WithEvents OpenFolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ST As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents BottomToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents TopToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents RightToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents LeftToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents ContentPanel As System.Windows.Forms.ToolStripContentPanel
    Friend WithEvents CM As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SEL As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents RunFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromLinkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScriptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoteShellToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenChatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromDISKToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromLINKToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UninstallToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisconnectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComputerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShutdownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebSiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlockWebSiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents L1 As Coringa.LV
    Friend WithEvents IM3 As System.Windows.Forms.ImageList
    Friend WithEvents ToolStripDropDownButton1 As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents PesonalizaçãoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lbPorts As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents WebcamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegeditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KeyloggerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SenhasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripDropDownButton2 As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents FragsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesktopToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripDropDownButton3 As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents CriarServidorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServidorNormalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DownloadURLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripDropDownButton4 As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents CréditosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExecutarInvisívelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExecutarNormalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents PicMineDesktop As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents CKMostrarDesktop As System.Windows.Forms.CheckBox
    Friend WithEvents CKMostrarInformações As System.Windows.Forms.CheckBox
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ServidorTestToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMNotificação As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConfiguraçõesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DockSite2 As DevComponents.DotNetBar.DockSite
    Friend WithEvents Bar1 As DevComponents.DotNetBar.Bar
    Friend WithEvents PanelDockContainer1 As DevComponents.DotNetBar.PanelDockContainer
    Friend WithEvents DockContainerItem1 As DevComponents.DotNetBar.DockContainerItem
    Friend WithEvents DockSite1 As DevComponents.DotNetBar.DockSite
    Friend WithEvents DockSite3 As DevComponents.DotNetBar.DockSite
    Friend WithEvents DockSite4 As DevComponents.DotNetBar.DockSite
    Friend WithEvents DockSite5 As DevComponents.DotNetBar.DockSite
    Friend WithEvents DockSite6 As DevComponents.DotNetBar.DockSite
    Friend WithEvents DockSite7 As DevComponents.DotNetBar.DockSite
    Friend WithEvents DockSite8 As DevComponents.DotNetBar.DockSite
    Friend WithEvents AutoHide As DevComponents.DotNetBar.DotNetBarManager
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents InformaçõesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem12 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem13 As ToolStripMenuItem
    Friend WithEvents GerenciadorDeArquivosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AvançadoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BasicoToolStripMenuItem As ToolStripMenuItem
End Class
